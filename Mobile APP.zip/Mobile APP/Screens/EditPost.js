import React, { useState, useEffect } from 'react';
import {KeyboardAvoidingView, ToastAndroid, ScrollView, View, TextInput, StyleSheet, TouchableOpacity, Text, ImageBackground, Image, Picker, CheckBox, Button, Switch, Keyboard} from 'react-native';
import { FontAwesome } from "react-native-vector-icons";
import { useDispatch, useSelector } from 'react-redux';

import { editPostData, editPostUpdate } from "../store/actions/editpostActions";

function EditPost({ navigation, route }) {     

    const dispatch = useDispatch();
    const selector = useSelector(state => state);
   
    const [title, setTitle] = useState('');     
    const [location, setLocation] = useState('');     
    const [description, setDescription] = useState('');     
    const [url, setUrl] = useState('');     
    const [category, setCategory] = useState('');     
    
    const [isVisible, setIsVisible] = useState(false);     
    const [isVisible1, setIsVisible1] = useState(false);     
    const [doc_id, setDoc_id] = useState('');     
    const [share, setShare] = useState(''); 
    
    const [userId, setUserId] = useState(''); 

    useEffect(() => {  
      console.log('Edit post page loaded 1');
         dispatch(editPostData(route.params.doc_idtest));                                             
                           
     },[]);

     useEffect(() => {
      console.log('Edit post page loaded 2');
         if(selector.PostEdit.datas){
            setUserId(selector.PostEdit.datas.userId);
            setTitle(selector.PostEdit.datas.title);     
            setLocation(selector.PostEdit.datas.location);     
            setDescription(selector.PostEdit.datas.description);     
            setUrl(selector.PostEdit.datas.url);     
            setCategory(selector.PostEdit.datas.category);    
            setShare(selector.PostEdit.datas.share);  
            setDoc_id(selector.PostEdit.datas.doc_id);                 
         }        
     }, [selector.PostEdit.datas])

    const Post = () => {            
        Keyboard.dismiss();       
        
        if(description == ''){
          alert('Please enter description');
        }
        else{
         // alert(userId);
         editPostUpdate(doc_id, description, share, userId, dispatch, navigation);
          //navigation.navigate('Profile');          
        }
    };
        
         
    const ToggleFunction = () => {
        setIsVisible(!isVisible);                        
    };
        
    const ToggleFunction1 = () => {
        setIsVisible1(!isVisible1);            
    };

    const toggleSwitch = value => {  
        setShare(value);
    }
       
    const cancel = () => {          
        navigation.navigate('Profile');
    }

    return (  
        <KeyboardAvoidingView behavior="position" enabled  style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        
            <View> 
            <Text style={{textAlign: 'center', fontSize: 20}}>Edit post</Text>            
            <Text></Text>
            <View style={{ 
              justifyContent: 'center',
            alignItems: 'center',
            }}>                         
            <ImageBackground style={{width: '100%', height: 220,
              borderRadius: 20,
              }} 
              imageStyle={{ borderRadius: 20 }}
              source={{uri: url}} >             
            </ImageBackground>                     
            </View>            
      
            <View style={{padding: 5, flex: 1, flexDirection:'row'}}><Text style={{color: '#000', fontSize: 16}}>{title}</Text><Text style={{color: 'gray', fontSize: 16}}>({category})</Text></View>
            <View style={{padding: 5}}><Text style={{color: 'gray', fontSize: 14}}><FontAwesome name='map-marker' size={20} color='gray' /> {location}</Text></View>
            <View style={{paddingTop: 20, paddingLeft: 5}}><Text style={{color: '#000', fontSize: 20}}>Description</Text></View>
                
            <TextInput
            style={styles.inputBox}
            value={description}
            multiline
            onChangeText={description => setDescription(description)}
            placeholder='Description'            
            />

            <View style={styles.terms}>                        
            <Text style={{fontFamily: 'Poppins-Regular',}}>Private Post</Text>                                              
            <Switch
            trackColor={{true: '#b3b3b3', false: '#262626'}}
            thumbTintColor={share == true ? '#b3b3b3' : '#262626'}            
            onValueChange={toggleSwitch}
            value = {share}/>                      
            </View>

            <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 30, paddingBottom: 30, flexDirection: 'row' }}>  
            <View >  
              <TouchableOpacity onPress={Post.bind(this)}>
              <View>    
              <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45,}} />
              <Text style={styles.buttonCentered1}>Update</Text>
              </View>
              </TouchableOpacity>
              </View>               
            <View >  
            <TouchableOpacity onPress={cancel.bind(this)}>
              <View>    
                <Image source={require('../assets/cancel.png')} style={{width: 120, height: 45,}} />
                <Text style={styles.buttonCentered1}>Cancel</Text>
              </View>
            </TouchableOpacity>
            </View>          
            </View>
            </View>
            <Text></Text>
            </ScrollView>
          </KeyboardAvoidingView>
    );
}
export default EditPost;


const styles = StyleSheet.create({
    container: {
        flex: 1,        
        alignItems: 'stretch',
        justifyContent: 'center',
        marginLeft: 20,
        marginRight: 20,
        flexDirection: 'column',
        fontFamily: 'Poppins-Regular',
    },
    inputBox: {
        height: 70,
        margin: 0,
        padding: 5,
        fontSize: 14,
        color: 'gray',
        borderBottomColor: 'gray',
        borderBottomWidth: 0.5,
        fontWeight: 'normal',
        fontFamily: 'Poppins-Regular'
    },
    terms: {
      margin: 10,
      padding: 15,
      fontSize: 16,
      fontWeight: 'normal',
        fontFamily: 'Poppins-Regular',
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center'
  },
  headerButtonsContainer: {
    flexDirection:'row',        
    paddingLeft: 5,  
    paddingRight: 5,
    alignItems: 'center',  
    fontFamily: 'Poppins-Regular'
  },
  headerButtons: {
    padding: 10,
    color: '#1C9E0B',
    fontFamily: 'Poppins-Regular'
  },
    button: {
        marginTop: 10,
        marginBottom: 20,
        paddingVertical: 5,
        position: 'relative',
        textAlign: 'center',
        alignItems: 'center',
        width: 150,
        height: 40,
        backgroundColor: '#BEBEC0',
        borderColor: '#BEBEC0',
        borderWidth: 1,
        borderRadius: 5,
        justifyContent: 'center',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText1: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText2: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonSignup: {
        fontSize: 12,
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonContainer: {
      position: 'relative',
      textAlign: 'center',
      color: '#fff',
      fontFamily: 'Poppins-Regular',
      width: 150,
      height: 100,
      justifyContent: 'center',
      alignItems: 'center',
    },
    buttonCentered1: {
      position: 'absolute',
      top: '28%',
      left: '30%',
      color: '#000',    
      fontFamily: 'Poppins-SemiBold',    
    },
  })
  