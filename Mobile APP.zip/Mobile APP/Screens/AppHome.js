import * as React from 'react';
import AppNavigator from '../Navigations/AppNavigator';

export default function AppHome() {
  return (       
      <AppNavigator />    
  );
}

  