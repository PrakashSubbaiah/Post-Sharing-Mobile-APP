import React, { useState } from 'react';

import { useDispatch, useSelector } from 'react-redux';

import {StyleSheet, Keyboard, Text, View, TextInput, Image, KeyboardAvoidingView, TouchableOpacity, SafeAreaView} from 'react-native';
import * as firebase from 'firebase';
import 'firebase/firestore';
import Icon from 'react-native-vector-icons/FontAwesome';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { logoutUser } from "../store/actions/authActions";
// A screen!
function ChangePassword({ navigation }) {
  
  console.log('Change password page loaded 1');

  const dispatch = useDispatch();
  const selector = useSelector(state => state);

  const [currentPassword, setCurrentPassword] = useState("");
  const [showPassword0, setShowPassword0] = useState(true);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(true);
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword1, setShowPassword1] = useState(true);
  
  
  
  reauthenticate = (currentPassword) => {
    var user = firebase.auth().currentUser;
    var cred = firebase.auth.EmailAuthProvider.credential(
        user.email, currentPassword);
    return user.reauthenticateWithCredential(cred);
  }

  changePassword = (currentPassword, newPassword) => {
    this.reauthenticate(currentPassword).then(() => {
      var user = firebase.auth().currentUser;
      user.updatePassword(newPassword).then(() => {
        console.log("Password updated!");
        alert('Password Updated successfully');
          console.log("password updated");
          dispatch(logoutUser());
      }).catch((error) => { console.log(error); });
    }).catch((error) => { console.log(error); });
  }
  let onSubmit = e => {
    e.preventDefault();
    Keyboard.dismiss();
    
    if(newPassword == confirmPassword){        
          changePassword(currentPassword, newPassword);        
    }else{
        alert('Please enter correct password in both');
    }    
  };


  return (
    <KeyboardAwareScrollView>      

      {/*<KeyboardAvoidingView behavior="padding" >*/}
          <View style={{ width: '90%',justifyContent: 'center', borderRadius: 10}}>

            <Text style={styles.title}>&nbsp;Change Password</Text>
            <View style={styles.contentLayout}>
            

            <Text>&nbsp;</Text>   
            <View style={{flexDirection: 'row', 
            borderColor: 'gray',
            borderWidth: 0.4,
            borderRadius: 20,
            height: 40, 
            backgroundColor: '#fff',
            elevation:6,
            shadowOffset: { width: 7, height: 7 },
            shadowColor: "black",
            shadowOpacity: 1,
            shadowRadius: 15,
            justifyContent: 'center', alignItems: 'center',
            left: 15,
           }}>
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
              <Icon name="lock" size={20} color="#4c4c4c" />
            </View>
            <Text>&nbsp;</Text>
            <TextInput style={{width: 210, fontFamily: 'Poppins-Regular', backgroundColor: '#fff'}} placeholder="Enter Current password" placeholderTextColor = "gray"
            value={currentPassword} onChangeText={currentPassword => setCurrentPassword(currentPassword)} 
            secureTextEntry={showPassword0} />            
            
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', marginLeft: 25}}>
            <TouchableOpacity>
            {showPassword0 === true?
              <TouchableOpacity onPress={showPassword0 => setShowPassword0(false)}>                
                <Icon name="eye-slash" value={!showPassword0} size={20} color="gray" />
              </TouchableOpacity>
            :
              <TouchableOpacity onPress={showPassword0 => setShowPassword0(true)}>                
                <Icon name="eye" value={!showPassword0} size={20} color="gray" />
              </TouchableOpacity>
            }
            </TouchableOpacity>
            </View>
            </View>


           
            <Text>&nbsp;</Text>   
            <View style={{flexDirection: 'row', 
            borderColor: 'gray',
            borderWidth: 0.4,
            borderRadius: 20,
            height: 40, 
            backgroundColor: '#fff',
            elevation:6,
            shadowOffset: { width: 7, height: 7 },
            shadowColor: "black",
            shadowOpacity: 1,
            shadowRadius: 15,
            justifyContent: 'center', alignItems: 'center',
            left: 15,
           }}>
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
              <Icon name="lock" size={20} color="#4c4c4c" />
            </View>
            <Text>&nbsp;</Text>
            <TextInput style={{width: 210, fontFamily: 'Poppins-Regular', backgroundColor: '#fff'}} placeholder="Enter New password" placeholderTextColor = "gray"
            value={newPassword} onChangeText={newPassword => setNewPassword(newPassword)} 
            secureTextEntry={showPassword} />            
            
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', marginLeft: 25}}>
            <TouchableOpacity>
            {showPassword === true?
              <TouchableOpacity onPress={showPassword => setShowPassword(false)}>                
                <Icon name="eye-slash" value={!showPassword} size={20} color="gray" />
              </TouchableOpacity>
            :
              <TouchableOpacity onPress={showPassword => setShowPassword(true)}>                
                <Icon name="eye" value={!showPassword} size={20} color="gray" />
              </TouchableOpacity>
            }
            </TouchableOpacity>
            </View>
            </View>


            <Text>&nbsp;</Text>   


            <View style={{flexDirection: 'row', 
            borderColor: 'gray',
            borderWidth: 0.4,
            borderRadius: 20,
            height: 40, 
            backgroundColor: '#fff',
            elevation:6,
            shadowOffset: { width: 7, height: 7 },
            shadowColor: "black",
            shadowOpacity: 1,
            shadowRadius: 15,
            justifyContent: 'center', alignItems: 'center',
            left: 15,
            }}>
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
              <Icon name="lock" size={20} color="#4c4c4c" />
            </View>
            <Text>&nbsp;</Text>
            <TextInput style={{width: 210, fontFamily: 'Poppins-Regular', backgroundColor: '#fff'}} placeholder="Enter Confirm password" placeholderTextColor = "gray"
            value={confirmPassword} onChangeText={confirmPassword => setConfirmPassword(confirmPassword)} 
            secureTextEntry={showPassword1} />            
            
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', marginLeft: 25}}>
            <TouchableOpacity>
            {showPassword1 === true?
              <TouchableOpacity onPress={showPassword1 => setShowPassword1(false)}>                
                <Icon name="eye-slash" value={!showPassword1} size={20} color="gray" />
              </TouchableOpacity>
            :
              <TouchableOpacity onPress={showPassword1 => setShowPassword1(true)}>                
                <Icon name="eye" value={!showPassword1} size={20} color="gray" />
              </TouchableOpacity>
            }
            </TouchableOpacity>
            </View>
            </View>
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>  
              <View style = {{ borderRadius: 15, justifyContent: 'center', width: '50%'}} >        
                <TouchableOpacity onPress={onSubmit}>
                  <View style={styles.buttonContainer}>                                                    
                    <Image source={require('../assets/Button-Bg.png')} style={{width: 165, height: 65, justifyContent: 'center', alignItems: 'center'}} />
                    <Text style={styles.buttonCentered1}>Update Password</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>               

            </View>
          </View>
          {/*</KeyboardAvoidingView>  */}
        </KeyboardAwareScrollView> 
    
  );
}

export default ChangePassword;


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Poppins-Regular'
      },
      title: {
        color: '#000',
        fontSize: 25,
        paddingTop: 20,
        paddingBottom: 20,
        textAlign: 'center',
        fontFamily: 'Poppins-Regular',
      },
      content: {        
        fontFamily: 'Poppins-Regular',
        alignItems: 'center',
        justifyContent: 'center',
      },
      buttonContainer: {
        position: 'relative',                                
        width: 210,
        height: 120,
        justifyContent: 'center',
        alignItems: 'center',
      },
      buttonCentered1: {
        position: 'absolute',
        top: '39%',        
        left: '20%',
        color: '#000',        
        fontFamily: 'Poppins-SemiBold',
      }
});
  