import React, { useState, useEffect, useRef } from 'react';
import { ScrollView, StyleSheet, Text, View, Image, SafeAreaView, FlatList, Keyboard} from 'react-native';

import moment from 'moment';


import { useDispatch, useSelector } from 'react-redux';

import { likedDetail } from "../store/actions/feedActions";
import { getProfilePicture} from "../store/actions/feedActions";

function ViewLikesPost({ route }) {
    
  const dispatch = useDispatch();
  const selector = useSelector(state => state);
  
    const [persons, setPersons] = useState([]);
    const [likesData, setLikesData] = useState([]);     
      
    useEffect(() => {  
      console.log('View Likes Post page loaded 1');
      
        setPersons(route.params.person);                 
        
        dispatch(likedDetail(route.params.person.doc_id)); 

      
     },[]);

     useEffect(() => {   
      dispatch(getProfilePicture());    
    },[]);
    
     const orderLikes = (data) => {     
       if(data){
      let returnArrComment = [];  
        returnArrComment = data.sort(function(a, b) {
          return (new Date(moment.unix(b.likedDate)) - new Date(moment.unix(a.likedDate)));
        });
        return returnArrComment;      
       }else{
         return data;
       }
    }
    const dateformat = (date) => {
      var postDate = moment.unix(date);
      var data = moment(postDate).startOf('minute').fromNow();
      return data;
    }
    const _handleTextReady = () => {
      console.log('ready!');
    }
    const Capitalize = (str) => {    
      return str.charAt(0).toUpperCase() + str.slice(1);
    }

  return (
    <ScrollView style={styles.container}>
    <View style={styles.sectionImageOutline}>              
          <Image source={{uri: persons.url}}  style={styles.sectionImage} />              
    </View>           
    <View style={styles.sectionBottomLikeComment}>
    <View style={styles.titleTag}>
    <Text style={styles.sectionTopTextBig}>{ persons.title || 'Loading' }</Text>                                                    
      <View style={styles.commentInline}>
        <Text style={styles.commentTextLeftComment}>
            {persons.description}
        </Text>
      </View>                           
    </View>                          
    </View>             
    
    <View style={styles.sectionBottomLikeComment}>    
      <View>
        <Text style={styles.sectionTopTextBig}>Liked Users:</Text>
      </View>
      

      {(selector.FeedPage.likedDetails != "undefined") && (selector.FeedPage.likedDetails != null) ?
<View>
                  <FlatList  
                    data={orderLikes(selector.FeedPage.likedDetails)}  
                    renderItem={({item}) =>  
                                         
                      <View style={styles.comments}>
                        <View>                         
                          {selector.FeedPage.profileUrls ?
                              <View>
                                {selector.FeedPage.profileUrls[item.userId]?                                    
                                  <Image source={{uri: selector.FeedPage.profileUrls[item.userId]}} style={styles.image} />                                  
                                  : 
                                  <Image source={require('../assets/pp.png')} style={styles.image} />
                                }
                              </View>
                             : 
                              <Image source={require('../assets/pp.png')} style={styles.image} />
                            }
                        </View>        
                        <View style={styles.commentContent}>                           
                        <View style={styles.commentInlineData}>
                          <Text style={styles.commentTextLeft}>{item.username} </Text>                                                              
                        </View>                        
                        <View style={styles.commentInlineData}>                          
                          <Text style={styles.commentTextRight}> {dateformat(item.likedDate)}</Text>                                                
                        </View>                        
                        </View>                            
                        </View>   

                        } 
                    ItemSeparatorComponent={null}  
                />                      
                </View>                
                :
                <View style={styles.commentInline}>
                  <Text style={styles.commentTextLeft, {paddingBottom: 30}}>*No Likes*</Text>
                </View>

}
      
                                                                         
    </View>
  </ScrollView> 
    );
  }

export default ViewLikesPost;

const styles = StyleSheet.create({
  container: {                         
      width: '100%',
      paddingBottom: 50,
      backgroundColor: '#fff',                
    },
    sectionImage: {
      width: '100%',
      height: 320,
      resizeMode: 'contain',
    },
    card: {
      marginHorizontal: 10,
      padding: 0,
      borderRadius: 3,        
      fontFamily: 'Poppins-Regular',
    },
    cardText: {
      fontSize: 12,
      color: 'gray',        
      textAlign: 'justify',
      fontFamily: 'Poppins-Regular',
    },
    content: {        
      fontFamily: 'Poppins-Regular'
    },
    sectionTopText: {
      paddingLeft: 5,
      paddingRight: 5,
      paddingTop: 0,
      paddingBottom: 0,
      fontFamily: 'Poppins-Regular',
    },
    sectionTopTextSmall: {
      paddingLeft: 5,
      paddingRight: 5,
      paddingTop: 0,
      paddingBottom: 0,
      fontSize: 12,
      color: 'gray',
      fontFamily: 'Poppins-Regular',
    },    
    sectionTopDateSmall: {
      paddingLeft: 10,
      paddingRight: 10,
      paddingTop: 10,
      paddingBottom: 0,
      fontSize: 12,
      color: 'gray',
      fontFamily: 'Poppins-Regular',
    },
    sectionTopTextBig: {
      paddingLeft: 10,
      paddingRight: 10,
      paddingTop: 0,
      paddingBottom: 0,
      fontSize: 16,
      color: '#000',
      fontFamily: 'Poppins-Regular',
    },
    titleTag: {    
      backgroundColor: '#fff',              
      marginTop: 30,
      marginBottom: 30,
      marginLeft: 10,
      marginRight: 10,
      paddingLeft: 10,  
      paddingRight: 10,
      paddingTop: 10,
      paddingBottom: 10,
      borderRadius: 100/10,      
      shadowColor: "gray",
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5,        
    }, 
    headerButtonsContainer: {
      flexDirection:'row',        
      paddingLeft: 5,  
      paddingRight: 5,
      alignItems: 'center',          
    },
    headerButtons: {
      padding: 10,        
    },
    sectionImageOutline: {
      width: '100%',
      height: 250,        
      backgroundColor: '#fff',
    },
    sectionImage: {
      width: '100%',
      height: 240,        
      alignContent: 'center',
      alignItems: 'center',        
    },      
    moreComments: {
      padding:10,
      paddingTop: 2,
      paddingBottom: 2,
      fontSize: 12,
      fontFamily: 'Poppins-Regular',
    },


    comments: {
      flexDirection:'row',             
      padding: 5,    
      width: '100%'        
    },
    image: {
      width: 50,
      height: 50,
      borderRadius: 50
    },       
    commentContent: {
      marginTop: -10,        
      padding: 10,        
      width: '100%'
    }, 
    commentInlineData: {        
      flex: 1,        
      flexDirection:'row',       
      paddingTop: 2,
      paddingBottom: 2,
    },      
    commentTextLeft: {        
      fontSize: 14,
      color: '#000',        
      fontFamily: 'Poppins-Regular',        
    },
    commentTextRight: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',                
      paddingTop: 0,
    },
    commentText: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',
      width: '85%',            
    },
    commentTextLeftComment: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',
      width: '100%',      
      padding: 10  
    },
});