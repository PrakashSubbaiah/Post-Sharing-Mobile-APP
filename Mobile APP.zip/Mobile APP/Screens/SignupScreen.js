import React, { useState, useEffect } from 'react';
import {StyleSheet, Picker, Keyboard, Text, View, TextInput, Image, KeyboardAvoidingView, ImageBackground, TouchableOpacity, SafeAreaView} from 'react-native';
import 'firebase/firestore';
import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';
import { signupUser } from "../store/actions/authActions";
import { GET_ERRORS } from "../store/actions/actionTypes";
import * as Network from 'expo-network';
import * as Device from 'expo-device';

function SignupScreen({ navigation }) {
  console.log('signup page loaded 1');
  const dispatch = useDispatch();
  const selector = useSelector(state => state);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(true);
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [countryCode, setCountryCode] = useState("");
  const [validates, setvalidates] = useState(false);
  const [status, setStatus] = useState("active");
  const [deviceName, setDeviceName] = useState("");
  const [modelName, setModelName] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [locationnow, setLocationNow] = useState("");

  const [loading, setLoading] = useState(true);
  
  useEffect(() => {       
    setLoading(false);
  },[]);


  useEffect(() => {  
    const networkInfo = async () => {
      let result = await Network.getIpAddressAsync();
      setIpAddress(result);
     }
   




     const deviceInfo = async () => {
       let result1 = Device.deviceName;
       let result2 = Device.modelName;
       setDeviceName(result1)
       setModelName(result2);
      }

      const locationss = async () => {
        try {
          let response = await fetch(
          'https://freegeoip.app/json/',
          );
          let responseJson = await response.json();
         // console.log(responseJson.country_name);
setLocationNow(responseJson.country_name);
console.log(locationnow);
if(locationnow == "India"){
setCountryCode('+91')
}
else if(locationnow == "Malaysia"){
  setCountryCode('+60')
}
    else if(locationnow == "Singapore"){
    setCountryCode('+65')
    }
    else{
      setCountryCode('+91')
    }
          return responseJson;
          } catch (error) {
          console.error(error);
          }
      }
     
locationss();
   networkInfo();
   deviceInfo();
  },[]);


  let validate = (text) => {
    console.log(text);
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
    if(reg.test(text) === false)
    {
    console.log("Email is Not Correct");
    setEmail(text);
    setvalidates(false);
    return false;
      }
    else {
      setEmail(text);
      setvalidates(true);
      console.log("Email is Correct");
    }
    }

   let onSignup = e  =>{
      e.preventDefault();
      
      Keyboard.dismiss();
      const newUser = { email: email,
              password: password,
              username: username,
              phone: `${countryCode}${phone}`,
              phoneNumber: phone,
              memberSince: moment().unix(),              
              lastLoggedIn: moment().unix(),              
              status: status,
              warning: [],
              noOfReportedPosts: 0,
              noOfPostReportedByHim: 0,
              noOfWarnings: 0,
              numberOfPosts: 0,
              deviceName: deviceName,
              ipAddress: ipAddress,
              modelName: modelName
            };

      if(validates === false){
        alert("Email is Not Correct")
      }
      else if(email == ''){
        alert("Please enter email")
      }
      else if(username < 3){
        alert("Please enter valid username")
      }
      else if(phone.length < 10 ){
        alert("Please enter 10 digit mobile number")
      }
      else if(password.length < 8 ){
        alert("Password must contain 8 characters")
      } else{
        dispatch({
          type: GET_ERRORS,
          payload: ''
        });
        setLoading(true);
        dispatch(signupUser(newUser, navigation));
       //console.log('success');
    }
  }

    return (
      <ImageBackground source={require('../assets/SignIn_Bg.png')}  style={{            
        width: '100%', 
        height: '100%',
        flex:1, 
        alignItems: 'center',
        justifyContent: 'center', }}>            
        <SafeAreaView style={{flex:1, width: '100%',
        alignItems: 'center',
        justifyContent: 'center',}}>
        <View style={{width: '100%',
        alignItems: 'center',
        justifyContent: 'center',}}>            
        <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: '70%', height: 65}} resizeMode='contain' />
        </View>
        <KeyboardAvoidingView behavior="padding" >                           
        <Text style={styles.title}>Sign Up</Text>
        <View style={styles.contentLayout}>
             
        <View style={{flexDirection: 'row', 
        borderColor: 'gray',
        borderWidth: 0.4,
        borderRadius: 20,
        height: 40, backgroundColor: '#fff'}}>
        <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center',}}>
          <Icon name="user" size={20} color="#4c4c4c" />
        </View>
        <Text>&nbsp;</Text>
        <TextInput style={{fontFamily: 'Poppins-Regular', width: '80%'}} value={username} placeholderTextColor = "gray" placeholder="Username/Nickname" onChangeText={username => setUsername(username)}/>
        </View>
        <Text></Text>

        <View style={{flexDirection: 'row', 
        borderColor: 'gray',
        borderWidth: 0.4,
        borderRadius: 20,
        height: 40, backgroundColor: '#fff'}}>
        <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center',}}>
          <Icon name="mobile" size={20} color="#4c4c4c" />
        </View>
        <Text>&nbsp;</Text>
        <View style={{height: 40, width: 20, alignItems: 'center', justifyContent: 'center',}}>
        <Icon name="caret-down" size={20} color="#4c4c4c" />
        </View>
        <View style={{height: 40, width: 40}}>
       
        <Picker selectedValue={countryCode}
        style={{fontFamily: 'Poppins-Regular', backgroundColor: '#fff',height: 39,width: 45, fontSize: 10}}
        itemtextStyle={{fontFamily: 'Poppins-Regular', fontSize: 10}}
        textStyle={{fontFamily: 'Poppins-Regular', fontSize: 10}}
        onValueChange={(itemValue, itemIndex) =>
              setCountryCode(itemValue)
              }>
                <Picker.Item label="+91" value="+91" />
          <Picker.Item label="+60" value="+60" />
          <Picker.Item label="+65" value="+65" />
              </Picker>
              </View>
        <TextInput style={{fontFamily: 'Poppins-Regular', width: '60%'}} keyboardType="phone-pad" maxLength={10} placeholderTextColor = "gray" placeholder="Enter your mobile number" value={phone} onChangeText={phone => setPhone(phone)}/>
        </View>
        <Text></Text>

        <View style={{flexDirection: 'row',  
        borderColor: 'gray',
        borderWidth: 0.4,
        borderRadius: 20,
        height: 40, backgroundColor: '#fff'}}>
        <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
            <Icon name="at" size={20} color="#4c4c4c" />
        </View>
        <Text>&nbsp;</Text>
        <TextInput style={{fontFamily: 'Poppins-Regular',width: '80%'}} autoCapitalize='none' placeholderTextColor = "gray" keyboardType="email-address" placeholder="Enter your email id" value={email} /*onChangeText={(email) => setState({ email })}*/ onChangeText={(text) => validate(text)}/>
        </View>
        <Text></Text>

        <View style={{flexDirection: 'row', 
         borderColor: 'gray',
         borderWidth: 0.4,
         borderRadius: 20,
         height: 40,
         fontFamily: 'Poppins-Regular',
         backgroundColor: '#fff'}}>
        <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
          <Icon name="lock" size={20} color="#4c4c4c" />
        </View>
           
        <TextInput  style={{width: 210, fontFamily: 'Poppins-Regular',}} placeholderTextColor = "gray" value={password} placeholder="Enter your password" onChangeText={password => setPassword( password )} secureTextEntry={showPassword} />
        <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', marginLeft: 15}}>
          {showPassword === true?
          <TouchableOpacity onPress={showPassword => setShowPassword(false)}>
            <Icon name="eye-slash" value={!showPassword} size={20} color="gray" />
          </TouchableOpacity>
          :
          <TouchableOpacity onPress={showPassword => setShowPassword(true)}>                   
            <Icon name="eye" value={!showPassword} size={20} color="gray" />
          </TouchableOpacity>
          }
        </View>
        </View>                   
        <Text></Text>
        <View style={{ justifyContent: 'center', alignItems: 'center' }}>  
        <View>    
          {loading?
                <View style={{justifyContent: 'center', alignItems: 'center'}}>                                                
                  <Image source={require('./loading_spinner.gif')} style={{justifyContent: 'center', alignItems: 'center', width: 100, height: 100}}></Image>                                              
                </View>       
                :
                <TouchableOpacity onPress={onSignup}>
                  <View style={styles.buttonContainer}>                                    
                    <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                    <Text style={styles.buttonCentered1}>Sign Up</Text>
                  </View>
                </TouchableOpacity>
          }      
          {/*<TouchableOpacity onPress={onSignup}>
            <View style={styles.buttonContainer}>                                    
              <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
              <Text style={styles.buttonCentered1}>Sign Up</Text>
            </View>
          </TouchableOpacity>*/}                              
        </View>
        </View>
       
     
        <View style={styles.contentInput}>      
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>  
            <Text style={{color:'gray', textAlign: 'center', fontSize: 12, padding: 10,fontFamily: 'Poppins-Regular',}}>Have an account? <Text style={{color: 'gray', fontWeight: 'bold', textAlign: 'center', fontFamily: 'Poppins-Regular',}} >Sign In</Text></Text>           
          </TouchableOpacity>
        </View>                  
        </View>                                              
        </KeyboardAvoidingView> 
        </SafeAreaView>            
        </ImageBackground>  
    );
  }


export default SignupScreen;

const styles = StyleSheet.create({
  container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Poppins-Regular'
    },
    title: {
      color: '#000',
      fontSize: 25,
      paddingTop: 10,
      textAlign: 'center',
      fontFamily: 'Poppins-Regular',
    },
    content: {        
      fontFamily: 'Poppins-Regular'
    },
    contentLayout: {
      padding: 10,
    },
    buttonContainer: {
      position: 'relative',
      textAlign: 'center',
      color: '#fff',
      fontFamily: 'Poppins-Regular',
      width: 150,
      height: 100,
      justifyContent: 'center',
      alignItems: 'center',
    },
    buttonCentered1: {
      position: 'absolute',
      top: '39%',
      left: '35%',
      color: '#000',        
      fontFamily: 'Poppins-Bold',
    },
});