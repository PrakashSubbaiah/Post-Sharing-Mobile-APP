import React, { useState, useEffect } from 'react';
import { StyleSheet, Keyboard, Text, View, TextInput, Image, KeyboardAvoidingView, ImageBackground, TouchableOpacity, SafeAreaView} from 'react-native';

import 'firebase/firestore';
import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';

import { loginUser } from "../store/actions/authActions";
import { GET_ERRORS } from "../store/actions/actionTypes";
function Login({ navigation  }) {
  //console.log('Login page loaded 1');
  const dispatch = useDispatch();
  const selector = useSelector(state => state);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(true);

  const [loading, setLoading] = useState(false);
  
  useEffect(() => {       
    setLoading(false);    
  },[]);


  
  

  let onSubmit = e => {
    
    e.preventDefault();
    
    dispatch({
      type: GET_ERRORS,
      payload: ''
    });
    setLoading(true);
    /*if(selector.loginPath.errorCode){
      setLoading(true);
    }*/
    Keyboard.dismiss();
    const authData = {
      email: email,
      password: password
    };    
    dispatch(loginUser(authData));
  };
  return (
    <ImageBackground source={require('../assets/authBg.png')}  style={{            
        width: '100%', 
        height: '100%',
        flex:1, 
        alignItems: 'center',
        justifyContent: 'center', }}>
        
        <SafeAreaView style={{flex:1, width: '100%',
        alignItems: 'center',
        justifyContent: 'center',}}>
        <View style={{width: '100%',
        alignItems: 'center',
        justifyContent: 'center',}}>  
                   
         <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: '70%', height: 65}} resizeMode='contain' />
         </View>     

        <KeyboardAvoidingView behavior="padding" >
          <View style={{ width: '90%',justifyContent: 'center', borderRadius: 10}}>

            <Text style={styles.title}>&nbsp;Sign In</Text>
            <View style={styles.contentLayout}>
            
            <View style={{flexDirection: 'row', 
            borderColor: 'gray',
            borderWidth: 0.4,
            borderRadius: 20,
            height: 40,
            backgroundColor: '#fff',
            elevation:6,
            shadowOffset: { width: 7, height: 7 },
            shadowColor: "black",
            shadowOpacity: 1,
            shadowRadius: 15,
  
            }}>
              
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center'}}>
              <Icon name="at" size={20} color="#4c4c4c"/>
            </View>
            <Text>&nbsp;</Text>            
            <TextInput style={{fontFamily: 'Poppins-Regular', width: '80%', backgroundColor: '#fff'}} autoCapitalize='none' keyboardType="email-address" placeholderTextColor = "gray" placeholder="Enter your email id" 
            value={email} onChangeText={email => setEmail(email)} />
            </View>       

            <View>
              {selector.loginPath.errorCode === "auth/user-not-found" ? 
              <Text style={{color: 'red', padding: 10,fontFamily: 'Poppins-Regular',}}>Email is not registered.</Text>      
              :
              <Text></Text>
              }
            </View>

            <View style={{flexDirection: 'row', 
            borderColor: 'gray',
            borderWidth: 0.4,
            borderRadius: 20,
            height: 40, 
            backgroundColor: '#fff',
            elevation:6,
            shadowOffset: { width: 7, height: 7 },
            shadowColor: "black",
            shadowOpacity: 1,
            shadowRadius: 15,}}>
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', }}>
              <Icon name="lock" size={20} color="#4c4c4c" />
            </View>
            <Text>&nbsp;</Text>
            <TextInput style={{width: 210, fontFamily: 'Poppins-Regular', backgroundColor: '#fff'}} placeholder="Enter your password" placeholderTextColor = "gray"
            value={password} onChangeText={password => setPassword(password)} 
            secureTextEntry={showPassword} />            
            
            <View style={{height: 40, width: 40, alignItems: 'center', justifyContent: 'center', marginLeft: 25}}>
            <TouchableOpacity>
            {showPassword === true?
              <TouchableOpacity onPress={showPassword => setShowPassword(false)}>                
                <Icon name="eye-slash" value={!showPassword} size={20} color="gray" />
              </TouchableOpacity>
            :
              <TouchableOpacity onPress={showPassword => setShowPassword(true)}>                
                <Icon name="eye" value={!showPassword} size={20} color="gray" />
              </TouchableOpacity>
            }
            </TouchableOpacity>
            </View>
            </View>
            <View>
            {selector.loginPath.errorCode === "auth/wrong-password" ? 
              <Text style={{color: 'red', padding: 10, fontFamily: 'Poppins-Regular',}}>Password entered is invalid.</Text>
            :
              <View></View>
        }
            </View>

            <View>
              {selector.loginPath.checkStatus == "inactive" ? 
                <Text style={{color: 'red', padding: 10, fontFamily: 'Poppins-Regular',}}>Account is blocked by admin.</Text>
              :
                null
              }
            </View>

            {/*<View style={{ justifyContent: 'center', alignItems: 'center' }}>  
              <View style = {{ borderRadius: 15, justifyContent: 'center', width: '50%'}} >        
                <TouchableOpacity onPress={onSubmit}>
                  <View style={styles.buttonContainer}>                                
                    <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                    <Text style={styles.buttonCentered1}>Sign In</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>*/}

            <View style={{ justifyContent: 'center', alignItems: 'center' }}>  
              <View style = {{ borderRadius: 15, justifyContent: 'center', width: '50%'}} >  

              {loading?
              <View>
                  {selector.loginPath.errorCode ?
                    <TouchableOpacity onPress={onSubmit}>
                      <View style={styles.buttonContainer}>                                
                        <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                        <Text style={styles.buttonCentered1}>Sign In</Text>
                      </View>
                    </TouchableOpacity>                    
                    :
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>                                                
                      <Image source={require('./loading_spinner.gif')} style={{justifyContent: 'center', alignItems: 'center', width: 100, height: 100}}></Image>                                              
                    </View>       
                  }
                </View>
                :
                <TouchableOpacity onPress={onSubmit}>
                  <View style={styles.buttonContainer}>                                
                    <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                    <Text style={styles.buttonCentered1}>Sign In</Text>
                  </View>
                </TouchableOpacity>
              }                      
              </View>
            </View>
            

            <View style={styles.contentInput}>  
              <TouchableOpacity onPress={() => navigation.navigate('Signup')}>              
                <Text style={{color:'gray', textAlign: 'center', fontSize: 12, padding: 10, fontFamily: 'Poppins-Regular',}}>Don't have an account? <Text style={{color: 'gray', fontWeight: 'bold', textAlign: 'center', fontFamily: 'Poppins-Regular',}} >&nbsp;Sign Up</Text></Text> 
              </TouchableOpacity>                                
            </View>       
            
            </View>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>     
        
    </ImageBackground>
     
    );

  }

export default Login;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Poppins-Regular'
      },
      title: {
        color: '#000',
        fontSize: 25,
        paddingTop: 20,
        paddingBottom: 20,
        textAlign: 'center',
        fontFamily: 'Poppins-Regular',
      },
      content: {        
        fontFamily: 'Poppins-Regular',
        alignItems: 'center',
        justifyContent: 'center',
      },
      buttonContainer: {
        position: 'relative',                        
        width: 150,
        height: 100,
        justifyContent: 'center',
        alignItems: 'center',
      },
      buttonCentered1: {
        position: 'absolute',
        top: '39%',
        left: '35%',
        color: '#000',        
        fontFamily: 'Poppins-SemiBold',
      }
});