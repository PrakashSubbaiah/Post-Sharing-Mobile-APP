import React, { useState, useEffect } from 'react';
import {AsyncStorage, Modal, TouchableWithoutFeedback, Alert, ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, FlatList} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesome } from "react-native-vector-icons";
import moment from 'moment';
import ReadMore from 'react-native-read-more-text';
import Icon from 'react-native-vector-icons/Entypo';

import { mypostData } from "../store/actions/profileActions";
import { logoutUser } from "../store/actions/authActions";
import { likeData, commentsData } from "../store/actions/feedActions";

import { PROFILE_PICTURE } from "../store/actions/actionTypes";

import * as firebase from 'firebase';
import 'firebase/firestore';
import {firestore, storage} from '../Config/Config';

import * as ImagePicker from "expo-image-picker";

function ProfileScreen({ navigation }) {
   
    const dispatch = useDispatch();
    const selector = useSelector(state => state);
  
    const [userId, setUserId] = useState('');        
    const [username, setUsername] = useState('');        
    const [email, setEmail] = useState('');        
    const [phoneNumber, setPhoneNumber] = useState('');   
    const [profileUrl, setProfileUrl] = useState('');
    const [warning, setWarning] = useState('');        

    const [myPosts, setMyPosts] = useState(true);        
    const [reports, setReports] = useState(false);               

    const [modalVisible, setModalVisible] = useState(false);        
    const [doc_idtest, setDoc_idtest] = useState('');       


    useEffect(() => {        
      console.log('Profile page loaded 1');
      const getUserData = async () => {  
        
        await AsyncStorage.getItem('userDetail').then((user_data_json) => {
          let userData = JSON.parse(user_data_json);         
          if (userData != null) {                      
            let userId = userData.user.uid;                                                                 
            firestore.collection('users').doc(userId).get().then((doc) => {
              if(doc.data().status == 'active'){            
                setUserId(doc.id);
                setPhoneNumber(doc.data().phone);
                setUsername(doc.data().username);
                setEmail(doc.data().email);     
                setProfileUrl(doc.data().profileUrl || '');
                setWarning(doc.data().Warning.length);                                  

              }            
            })
          }   
    
      });
    
      }
    
      getUserData();     

     },[]);
    
     useEffect(() => {    
      console.log('Profile page loaded 2');    
       if(userId){                 
        dispatch(mypostData(userId, {dispatch}));                                    
       }                   
    },[userId],[selector.ProfilePage.datas]);

    useEffect(() => {   
      console.log('Feed page loaded 3 like details');
      dispatch(likeData());  
    },[]);

    useEffect(() => {   
      console.log('Feed page loaded 4 comments details');
      dispatch(commentsData());  
    },[]);


    const dateformat = (date) => {          
        var postDate = moment.unix(date);
        var data = moment(postDate).startOf('minute').fromNow();
        return data;
      }
          
      
     const chooseFile = async () => {      
        let result = await ImagePicker.launchImageLibraryAsync();
        let name = result.uri.split('/').pop();
        let ext = name.split('.').pop();
      //let filename = moment().unix() + phoneNumber + '.' + ext;  
      let filename = userId + '.' + ext;  
        if(!result.cancelled) {          
          await profilePicture(result.uri, filename, userId)
          .then((data) => {
            alert("Profile picture uploaded successfully");  
            if(data){   
              alert(data);
              setProfileUrl(data);
            }
          })
          .catch((error) => {
            alert(error);
          });
        }
      }
     
       
  const profilePicture = async (uri, imageName, userId) => {
       
        let profileUrls = '';
        let imageNames = '';
       
          const response = await fetch(uri);
          const blob = await response.blob();
      
          await storage.ref().child("profile/" + imageName).put(blob);
          
          await storage.ref('profile').child(imageName).getDownloadURL().then(url => {
                console.log(url);                
                profileUrls = url;
                imageNames = imageName;
 
            }).then(() => {
              firestore.collection('users').doc(userId).update({ profileUrl: profileUrls, imageName: imageNames}).then(() => {              
                firestore.collection('userProfilePicture').doc('url').set({ [userId]: profileUrls }, { merge: true }).then(()=>{                             
                 let updatedProfileData = {                    
                     profileUrl: profileUrls
                 }                           
                 setProfileUrl(profileUrls);                    

                /*Updated details refresh in Reducer Start*/
                 firestore.collection('userProfilePicture').get().then((querySnapshot) => {                       
                  let returnArrays = [];          
                  querySnapshot.forEach(function(doc){          
                      returnArrays.push(doc.data());                           
                  });                        
                  var result = returnArrays.reduce(function(result, item){     
                    return item;
                  }, {});   
                  console.log(result);
                  return dispatch({
                    type: PROFILE_PICTURE,      
                    payload: result
                  });                      
                });
                /*Updated details refresh in Reducer End*/                

                });

               })
            })
      
        
        };        
    
      editPost = (doc_idtest) => {          
        setModalVisible(!modalVisible);
        navigation.navigate('EditPost', {
          doc_idtest: doc_idtest,            
        });      
      }
    
    
      deletePost = (doc_idtest) => {          
        setModalVisible(!modalVisible);        
        Alert.alert(
           '',
           'Are you sure want to delete?',
           [
             {
               text: 'Cancel',
               onPress: () => console.log('Cancel Pressed'),
               style: 'cancel'
             },
             {text: 'Delete',
              onPress: () =>  firestore.collection('post').doc(doc_idtest).update({deleteFlag: true}).then(() => {
                
                firestore.collection('users').doc(userId).set({
                  myPost: {
                    [doc_idtest]: {deleteFlag: true},
                  },
                }, { merge: true }).then(() => { 
                  dispatch(mypostData(userId));
                });                

              }),
              style: 'destructive'
            },  
           ],
           {cancelable: false},
         );
        }
    
       
      const setModalVisiblePopup = (visible, data) => {              
        setModalVisible(visible);
        setDoc_idtest(data)
      }
    
    const _handleTextReady = () => {          
      //console.log('ready!');
    }
    
    const viewComments = (person) => {                           
      navigation.navigate('ViewCommentsPost', {
        person: person,            
      }); 
    }

    const viewLikes = (person) => {                
      navigation.navigate('ViewLikesPost', {
        person: person,            
      });       
    }
    
    const reportAuthoring = (person, doc_idtest) => {        
      setModalVisible(!modalVisible);      
    }
    
    const setMyPostsTab = () => {          
        setMyPosts(true);
        setReports(false);
    }

    const setReportsTab = () => {          
      setMyPosts(false);
      setReports(true);
    }

    const Warning = () => {      
      navigation.navigate('WarningPage', {
        userId: userId,            
      }); 
    }

    
    const ChangePassword = () => {
      console.log('15');
      navigation.navigate('ChangePassword', {
        userId: userId,            
      }); 
    }

        return (
          <ScrollView style={styles.containerOutline}>
            <View style={styles.container}>
              
              <View style={{flexDirection: "row"}}>        
              
                {profileUrl == ''? 
                <View style={styles.ppContainer}>                     
                  <Image source={require('../assets/pp.png')} style={styles.image} />                
                  <View style={styles.buttonPP}> 
                    <TouchableOpacity onPress={chooseFile} >  
                      <Image source={require('../assets/Changeimg.png')} style={styles.imageEdit} />
                    </TouchableOpacity>
                  </View>
                </View>
                :
                <View style={styles.ppContainer}> 
                  <Image source={{uri: profileUrl}} style={styles.image} />                
                  <View style={styles.buttonPP}>
                    <TouchableOpacity onPress={chooseFile} >  
                      <Image source={require('../assets/Changeimg.png')} style={styles.imageEdit} />
                    </TouchableOpacity>
                  </View>
                </View>
                }
                
                <View style={{padding: 10, paddingTop: 20}}>  
                <View style={{ flexDirection: 'row', paddingTop: 3, paddingBottom: 3 }}>
                <Icon name="user" size={20} color="gray"/>  
                <Text style={{fontFamily: 'Poppins-Regular', color: 'gray', fontSize: 14,}}>&nbsp;{username}</Text>   
                </View>
                <View style={{ flexDirection: 'row', paddingTop: 3, paddingBottom: 3 }}>
                <Icon name="mail" size={20} color="gray" />   
                <Text style={{fontFamily: 'Poppins-Regular', color: 'gray', fontSize: 14,}}>&nbsp;{email}</Text> 
                </View>
                <View style={{ flexDirection: 'row', paddingTop: 3, paddingBottom: 3 }}>
                <Icon name="mobile" size={20} color="gray" />        
                <Text style={{fontFamily: 'Poppins-Regular', color: 'gray', fontSize: 14,}}>&nbsp;{phoneNumber}</Text> 
                </View>
                <TouchableOpacity onPress={Warning}>
                <View style={{ flexDirection: 'row', paddingTop: 3, paddingBottom: 3 }}>                
                <Icon name="warning" size={20} color="gray" />  
                <Text style={{fontFamily: 'Poppins-Regular', color: 'gray', fontSize: 14,}}>&nbsp;{warning}&nbsp;Warning</Text>                  
                </View>
                </TouchableOpacity>

                <TouchableOpacity onPress={ChangePassword}>
                <View style={{ flexDirection: 'row', paddingTop: 3, paddingBottom: 3 }}>                
                <Icon name="eye" size={20} color="gray" />  
                <Text style={{fontFamily: 'Poppins-Regular', color: 'gray', fontSize: 14,}}>&nbsp;Change Password</Text>                  
                </View>
                </TouchableOpacity>


                <TouchableOpacity onPress={() => dispatch(logoutUser())}>
                  <View style={styles.buttonContainer}>                      
                      <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                      <Text style={styles.buttonCentered}>Sign Out</Text>
                  </View>
                </TouchableOpacity>                    
                </View>
                </View>     
          
              <View
              style={{        
              borderBottomColor: '#d3d3d3',
              borderBottomWidth: 5,            
              marginTop: -20,     
              }}
              />
      
              <View>        
              <View style={{padding: 10}}>
              <View style={styles.titleTab}>
                <View style={{width: '45%'}}><TouchableOpacity onPress={setMyPostsTab}><Text style={{textAlign: 'center', fontFamily: 'Poppins-Regular', color: myPosts? '#000' : '#b3b3b3', fontSize: 16, fontWeight: 'bold', padding: 10, borderRadius: 15}}>My Posts</Text></TouchableOpacity></View>
                <View style={{width: '45%'}}><TouchableOpacity onPress={setReportsTab}><Text style={{textAlign: 'center', fontFamily: 'Poppins-Regular', color: reports? '#000' : '#b3b3b3', fontSize: 16, fontWeight: 'bold', padding: 10, borderRadius: 15}}>Reports</Text></TouchableOpacity></View>
              </View>
              </View>
              { myPosts ?
              <View>
                
              {selector.ProfilePage.datasLength == '1' ? 
              <View>                
                {(selector.ProfilePage.datas.length > 0 && selector.ProfilePage.datas.length != null) ?
                
                <View>

                <FlatList  
                    data={selector.ProfilePage.datas}  
                    renderItem={({item, index}) =>  
                    <View style={styles.sectionoutline}>                     
                  <View style={styles.imageContainer}>                      
                    <Image source={{uri: item.url}} style={styles.sectionImage} />                        
                    <TouchableOpacity onPress={() => setModalVisiblePopup(!modalVisible, item.doc_id)} style={styles.buttonCorner}>
                      <Icon name="dots-three-vertical" size={20} color="#fff" />
                    </TouchableOpacity>
                  </View>
                    
                  <Modal
                      animationType=""
                      transparent={true}
                      visible={modalVisible}
                      onRequestClose={() => {
                          alert('Modal has been closed.');                    
                  }}>
                  <TouchableWithoutFeedback style={{backgroundColor: 'red'}} onPress={() => setModalVisiblePopup(!modalVisible)}>                  
      
                  <View style={{
                              flex: 1,
                             /* backgroundColor: 'rgba(52, 52, 52, 0)',*/
                              position: 'absolute',
                              top: 0,
                              right: 0,
                              left: 0,
                              bottom: 0
                          }}>
                  <View style={{
                        flex: 1,
                        flexDirection: 'column',
                        backgroundColor: '#fff',                           
                        borderRadius: 2,
                        shadowRadius: 10,
                        marginTop: '90%',                      

                        }}>                          
                  <View>                        
                    
      
                      <TouchableOpacity onPress={editPost.bind(this, doc_idtest)}>
                        <View style={{marginTop: 10, alignItems: 'center', borderBottomColor: '#bfbfbf', borderBottomWidth: 1}}>                         
                            <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray', paddingTop: 10, paddingBottom: 10}}>Edit</Text>
                        </View>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={deletePost.bind(this, doc_idtest)}>
                        <View style={{marginTop: 10, alignItems: 'center', borderBottomColor: '#bfbfbf', borderBottomWidth: 1 }}>                       
                          <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray', paddingTop: 10, paddingBottom: 10}}>Delete</Text>                                
                        </View>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={setModalVisiblePopup.bind(this, !modalVisible)}>
                        <View style={{marginTop: 10, alignItems: 'center' }}>                        
                          <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray'}}>Cancel</Text>                                
                        </View>
                      </TouchableOpacity>
                  </View>
                  </View>                        
                  </View>                        
                  </TouchableWithoutFeedback>
                  </Modal>
                  <Text style={styles.sectionTopTextBig}>{ item.title || 'Loading' }</Text>
                  <Text style={styles.sectionTopTextSmall}>{item.category}</Text> 
      
                  <View style={styles.sectionBottomLikeComment}>
                    <View style={styles.card}>
                      <ReadMore
                        numberOfLines={2}
                        onReady={_handleTextReady}>
                        <Text style={styles.cardText}>
                        {item.description}
                        </Text>
                      </ReadMore>
                    </View>
                  </View>
      
                  <View style={styles.sectionBottomLikeComment}>                                                                                                            
                     <TouchableOpacity onPress={viewLikes.bind(this, item)}>
                        <Text style={styles.sectionBottomText}><FontAwesome name='thumbs-o-up' size={20} color='gray' /> {selector.FeedPage.likesData[item.doc_id]} Likes</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={viewComments.bind(this, item)}>
                        <Text style={styles.sectionBottomText}>View {selector.FeedPage.commentsCountData[item.doc_id]} Comments</Text>
                      </TouchableOpacity>                  
                  </View>
                                                                                         
                  </View>   
                        } 
                    ItemSeparatorComponent={null}  
                />

                </View>
                :
                <View style={styles.loading}>                  
                  <Text style={styles.loadingText}>No Posts are found.</Text>
                </View>
                }
              </View>          
              :
              <View style={styles.loading}>
                <Text style={styles.loadingText}>Loading...</Text>
              </View>
              } 
              
              </View>
            :
            <View style={styles.loading}>
            <Text style={styles.loadingText}>No Reports</Text>
            </View>            
            }
              </View>
            
            </View>
            </ScrollView>
        );
}
export default ProfileScreen;



const styles = StyleSheet.create({
  containerOutline: {               
  width: '100%',                
  backgroundColor: '#fff',            
  flex: 1,    
  flexDirection: 'column',  
  },  
container: {
  width: '100%',
  paddingBottom: 50,
  backgroundColor: '#fff',          
},
titleTab: {
  flex: 1,    
  flexDirection: 'row',  
  justifyContent: 'space-between',  
},
sectionoutline: {                
  borderBottomColor: '#d3d3d3',
  borderBottomWidth: 5, 
  paddingTop: 10,
  paddingBottom: 10
  }, 
image: {
  width: 80,
  height: 80,
  borderRadius: 50,
  padding: 20,
  borderColor: '#BEBEC0',
  borderWidth: 2,
},
imageEdit: {
  width: 30,
  height: 30,
  borderRadius: 50,  
},
inputBox: {
  width: '85%',
  margin: 10,
  padding: 15,
  fontSize: 16,
  borderColor: '#d3d3d3',
  borderBottomWidth: 1,
  textAlign: 'center'
},
button: {
  marginTop: 30,
  marginBottom: 20,
  paddingVertical: 5,
  alignItems: 'center',
  backgroundColor: '#BEBEC0',
  borderColor: '#BEBEC0',
  borderWidth: 1,
  borderRadius: 5,
  width: 200
},
buttonText: {
  fontSize: 20,
  fontWeight: 'bold',
  color: '#fff'
},
buttonContainer: {
  position: 'relative',  
  width: 150,
  height: 100,
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: -10,
},
buttonCentered: {
  position: 'absolute',
  top: '39%',
  left: '32%',
  color: '#000',  
  fontFamily: 'Poppins-SemiBold',
},
imageContainer: {
  position: 'relative',  
  width: '100%',
  height: 250,
  padding: 10,
  justifyContent: 'center',
  alignItems: 'center',
},
buttonCorner: {
  position: 'absolute',
  top: '10%',
  left: '85%',  
  padding: 20,

},
ppContainer: {
  position: 'relative',  
  width: 150,
  height: 100,
  paddingTop: 10,
  justifyContent: 'center',
  alignItems: 'center',
},
buttonPP: {
  position: 'absolute',
  top: '70%',
  left: '60%',  
},
sectionImage: {
  width: '100%',
  height: 240,
  padding: 10,
  borderRadius: 20,
  alignContent: 'center',
  alignItems: 'center',  
},
sectionTopTextBig: {
  paddingLeft: 10,
  paddingRight: 10,
  paddingTop: 0,
  paddingBottom: 0,
  fontSize: 16,
  color: '#000',
  fontFamily: 'Poppins-Regular',
},
sectionTopTextSmall: {
  paddingLeft: 10,
  paddingRight: 10,
  paddingTop: 0,
  paddingBottom: 0,
  fontSize: 12,
  color: 'gray',
  fontFamily: 'Poppins-Regular',
},
sectionBottomLikeComment: {
  justifyContent: 'space-between',
  flex: 1,
  flexDirection:'row',
},
sectionBottomText: {
  padding:10,
  color: 'gray',
  fontFamily: 'Poppins-Regular',
},  
card: {
  marginHorizontal: 10,
  padding: 0,
  borderRadius: 3,  
},
cardText: {
  fontSize: 12,
  color: 'gray',        
  textAlign: 'justify',
  fontFamily: 'Poppins-Regular',
},
loading: {        
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center', 
},
loadingText: {    
  padding: 20,
  fontSize: 18,
  color: 'gray',
  fontFamily: 'Poppins-Regular'
},
});
