import React, { useState, useEffect } from 'react';
import {AsyncStorage, ScrollView, StyleSheet, Text, View, Image, FlatList} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import ReadMore from 'react-native-read-more-text';
import { warningData } from "../store/actions/profileActions";

function WarningPage() {
  
  
  const dispatch = useDispatch();
  const selector = useSelector(state => state); 

  const [userId, setUserId] = useState('');
  
  useEffect(() => {  
    console.log('Warning page loaded 1');
      const getUserData = async () => {            
        await AsyncStorage.getItem('userDetail').then((user_data_json) => {
          let userData = JSON.parse(user_data_json);         
          if (userData != null) {                      
            setUserId(userData.user.uid);                                                              
          }         
        });      
      }      
      
      getUserData();        
  },[]);

  useEffect(() => {  
    console.log('Warning page loaded 2');
      if(userId){                 
      dispatch(warningData(userId));                                    
      }               
  },[userId]);
  
  const _handleTextReady = () => {
    //console.log('ready!');
  }
  
  return (
    <ScrollView style={styles.containerOutline}>
            <View style={styles.container}>
                            
              {selector.ProfilePage.warningLength == '1' ? 
              <View>                
                {(selector.ProfilePage.warningData.noOfWarnings > 0 && selector.ProfilePage.warningData.noOfWarnings != null) ?
                <View>
                  
                {selector.ProfilePage.warningData.Warning.map((person, i) => (                                  
                  <View style={styles.sectionoutline} key={i}>                     
                  <View style={styles.imageContainer}>                      
                    <Image source={{uri: person.url}} style={styles.sectionImage} />                                            
                  </View>                                      
                  <Text style={styles.sectionTopTextBig}>{ person.title || 'Loading' }</Text>                  
                  <View style={styles.sectionBottomLikeComment}>
                        <View style={styles.card}>
                        <Text style={{color: 'red'}}>Warning Reason:</Text>
                        <ReadMore
                            numberOfLines={2}
                            onReady={_handleTextReady.bind(this)}>
                            <Text style={styles.cardText}>
                            {person.warning}
                            </Text>
                        </ReadMore>
                        </View>
                    </View>                  
                                                                                         
                  </View>
                  ))}
                </View>
                :
                <View style={styles.loading}>                  
                  <Text style={styles.loadingText}>No Warnings are found.</Text>
                </View>
                }
              </View>          
              :
              <View style={styles.loading}>
                <Text style={styles.loadingText}>Loading...</Text>
              </View>
              }                            
              
              </View>           
            </ScrollView> 
    );
  }

export default WarningPage;

const styles = StyleSheet.create({
    containerOutline: {               
    width: '100%',                
    backgroundColor: '#fff',            
    flex: 1,    
    flexDirection: 'column',  
    },  
  container: {
    width: '100%',
    paddingBottom: 50,
    backgroundColor: '#fff',          
  },  
  sectionoutline: {                
    borderBottomColor: '#d3d3d3',
    borderBottomWidth: 5, 
    paddingTop: 10,
    paddingBottom: 10
    }, 
  imageContainer: {
    position: 'relative',  
    width: '100%',
    height: 250,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },  
  sectionImage: {
    width: '100%',
    height: 240,
    padding: 10,
    borderRadius: 20,
    alignContent: 'center',
    alignItems: 'center',  
  },
  sectionTopTextBig: {
    paddingLeft: 10,
    paddingRight: 10,
    paddingTop: 0,
    paddingBottom: 0,
    fontSize: 16,
    color: '#000',
    fontFamily: 'Poppins-Regular',
  },  
  sectionBottomLikeComment: {
    justifyContent: 'space-between',
    flex: 1,
    flexDirection:'row',
  },
  card: {
    marginHorizontal: 10,
    padding: 0,
    borderRadius: 3,  
  },
  cardText: {
    fontSize: 12,
    color: 'gray',        
    textAlign: 'justify',
    fontFamily: 'Poppins-Regular',
  },
  loading: {        
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center', 
  },
  loadingText: {    
    padding: 20,
    fontSize: 18,
    color: 'gray',
    fontFamily: 'Poppins-Regular'
  },
  });
  