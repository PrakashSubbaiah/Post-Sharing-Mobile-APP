import React, { useState, useEffect, useRef } from 'react';
import {AsyncStorage, ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, Modal, TouchableWithoutFeedback, SafeAreaView, FlatList, Keyboard} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesome } from "react-native-vector-icons";
import moment from 'moment';
import { commentData, handleComment } from "../store/actions/feedActions";
import { TextInput } from 'react-native-gesture-handler';
import 'firebase/firestore';
import { auth, firestore } from '../Config/Config';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { getProfilePicture} from "../store/actions/feedActions";
import Icon from 'react-native-vector-icons/Entypo';

import { COMMENT_DATA } from "../store/actions/actionTypes";

// A screen!
function ViewComments({ route, navigation }) {

  const dispatch = useDispatch();
  const selector = useSelector(state => state);
  const inputRef = useRef(null)  

  const [userId, setUserId] = useState('');
  const [phone, setPhone] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');    
  const [comments, setComments] = useState('');  
  const [keyboardValue, setKeyboardValue] = useState(120);
  const [modalVisible1, setModalVisible1] = useState(false);
  const [userUID, setUserUID] = useState('');
  const [doc_idtest, setDoc_idtest] = useState('');



useEffect(() => {  
  console.log('View Comments Feed page loaded 1');  
  inputRef.current.focus(); 
  
  dispatch(commentData(route.params.person.doc_id)); 
  const getUserData = async () => {  
    
    await AsyncStorage.getItem('userDetail').then((user_data_json) => {
      let userData = JSON.parse(user_data_json);         
      if (userData != null) {                      
        let userId = userData.user.uid;                   
        firestore.collection('users').doc(userId).get().then((doc) => {
          if(doc.data().status == 'active'){            
            setUserId(doc.id);
            setPhone(doc.data().phone);
            setUsername(doc.data().username);
            setEmail(doc.data().email);                    
          }            
        })
      }   

  });

  }
  
  getUserData();   
   
 },[]);

 useEffect(() => {   
  dispatch(getProfilePicture());    
},[]);

 useEffect(() => {
  console.log('View Comments Post page loaded 2');  
  const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', _keyboardDidShow.bind(this),);
  const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', _keyboardDidHide.bind(this),);

  // returned function will be called on component unmount 
  return () => {
    keyboardDidShowListener.remove();
    keyboardDidHideListener.remove();
  }
}, [keyboardValue])

 
const _keyboardDidShow = () => {    
  //alert('Show');
  setKeyboardValue(120);     
}
const _keyboardDidHide = () => {  
  //alert('Hide');
  setKeyboardValue(0);       
}



const orderComments = (data) => {
  let returnArrComment = [];  
    returnArrComment = data.sort(function(a, b) {
      return (new Date(moment.unix(b.commentDate)) - new Date(moment.unix(a.commentDate)));
    });
    return returnArrComment;      
}
const dateformat = (date) => {
  var postDate = moment.unix(date);
  var data = moment(postDate).startOf('minute').fromNow();
  return data;
}
const _handleTextReady = () => {
  //console.log('ready!');
}
const Capitalize = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
}


const handleCommentSend = () => { 
  
  if(!comments || comments == undefined || comments == ''){
    alert("Please enter the valuable comments.");        
  }else{
    Keyboard.dismiss();
    inputRef.current.focus(null);  
    let doc_id = route.params.person.doc_id;
if(selector.FeedPage.commentsData){
      datas = [...selector.FeedPage.commentsData, { phone: phone, 
        email: email, 
        username: username,
        userId: userId,
        commentDate: moment().unix(),
        comment: comments,
        flag: 'active'
        }];
      dispatch({
        type: COMMENT_DATA,
        payload: datas
      });
  }else{
    datas = [{ phone: phone, 
      email: email, 
      username: username,
      userId: userId,
      commentDate: moment().unix(),
      comment: comments,
      flag: 'active'
      }];
    dispatch({
      type: COMMENT_DATA,
      payload: datas
    });
  }
  Keyboard.dismiss();
    handleComment(comments, userId, username, email, phone, route.params.person, selector.FeedPage.commentsCountData[doc_id], dispatch);
    setComments('');
            
  
    
  }  

}


const setModalVisibles1 = (visible, data, data1) => {
  setModalVisible1(!modalVisible1);   
  setDoc_idtest(data);   
  setUserUID(data1);              
}
const flagInapp = (doc_idtest) => {  
 setModalVisible1(!modalVisible1);   
 // alert(doc_idtest); 
  navigation.navigate('FlagAsInappropriate', {
      doc_idtest: doc_idtest,            
    });  
} 


  return (    
        <KeyboardAwareScrollView
              contentContainerStyle={{
                  flex: 1,
                  flexDirection: 'column',
                  justifyContent: 'flex-end',
                  alignItems: 'center',                  
              }}
              extraScrollHeight={0}>              
                  <View style={styles.containerOutline}>    

                   <ScrollView style={styles.container}>
            <View style={styles.sectionImageOutline}>              
                  <Image source={{uri: route.params.person.url}}  style={styles.sectionImage} /> 
                  <TouchableOpacity onPress={() => setModalVisibles1(!modalVisible1, route.params.person.doc_id, route.params.person.userUid)} style={styles.buttonCorner}>
                                  <Icon name="dots-three-vertical" size={20} color="#fff" />
                            </TouchableOpacity>         

                            <Modal
                      animationType=""
                      transparent={true}
                      animationInTiming={0}
                      visible={modalVisible1}
                      onRequestClose={() => {
                    alert('Modal has been closed.');                    
                    }}>

                    <TouchableWithoutFeedback style={{backgroundColor: 'red'}}
                                          onPress={() => setModalVisibles1(!modalVisible1)}>
                    
                    <View style={{
                            flex: 1,
                            /*backgroundColor: 'rgba(52, 52, 52, 0.1)',*/                            
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            left: 0,
                            bottom: 0
                        }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'column',
                        backgroundColor: '#fff',
                        borderRadius: 2,
                        shadowRadius: 10,
                        marginTop: 350,
                    }}>
                      
                    <View style={{ height: 300 }}>
                   
                   {userId == route.params.person.userUid?
                    null
                    :
                         <TouchableOpacity onPress={flagInapp.bind(this, doc_idtest)}>
                            <View style={{marginTop: 10, alignItems: 'center', borderBottomColor: '#bfbfbf', borderBottomWidth: 1}}>
                                <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray', paddingTop: 10, paddingBottom: 10}}>Flag as inappropriate</Text>
                            </View>
                         </TouchableOpacity>
                    }
                    <TouchableOpacity onPress={() => setModalVisibles1(!modalVisible1)}>
                        <View style={{marginTop: 10, alignItems: 'center' }}>                        
                          <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray'}}>Cancel</Text>                                
                        </View>
                    </TouchableOpacity>                            
                    </View>
                    </View>                        
                    </View>
                    </TouchableWithoutFeedback>
                    </Modal> 

            </View>   
            <View style={styles.sectionBottomLikeComment}>
              <View style={styles.titleTag}>
                  <Text style={styles.sectionTopTextBig}>{ route.params.person.title || 'Loading' }</Text>                                                    
                  <View style={styles.commentData}>
                    <Text style={styles.commentTextLeftComment}>
                        {route.params.person.description}
                    </Text>
                  </View>                           
              </View>                          
            </View>                          
            <View style={{paddingBottom: 70}}>    
                <View>
                  <Text style={styles.sectionTopTextBig}>Comments:</Text>
                </View>

{selector.FeedPage.commentLength == '1' ? 
<View>
{selector.FeedPage.commentsData ?
<View>
                  <FlatList  
                    data={orderComments(selector.FeedPage.commentsData)}  
                    renderItem={({item}) =>  
                    <View style={styles.comments}>
                    <View>
                      {/*<Image source={require('../assets/pp.png')} style={styles.image} />*/}
                      {selector.FeedPage.profileUrls ?
                              <View>
                                {selector.FeedPage.profileUrls[item.userId]?                                    
                                  <Image source={{uri: selector.FeedPage.profileUrls[item.userId]}} style={styles.image} />                                  
                                  :                                   
                                  <Image source={require('../assets/pp.png')} style={styles.image} />                                  
                                }
                              </View>
                             :                              
                              <Image source={require('../assets/pp.png')} style={styles.image} />                                                            
                      }
                    </View>                      
                    <View style={styles.commentContent}>                           
                      <View style={styles.commentInlineData}>
                        <Text style={styles.commentTextLeft}>{item.username}: </Text>                                    
                        <Text style={styles.commentTextRight}> {dateformat(item.commentDate)}</Text>                                                
                      </View>
                      <View style={{width: '100%'}}>
                        <Text style={styles.commentText}>{item.comment}</Text>                          
                      </View>
                    </View>        
                  </View>       
                  }  
                    ItemSeparatorComponent={null}  
                />                      
                </View>                
                :
                <View style={styles.commentInline}>
                                  <Text style={styles.commentTextLeft, {paddingBottom: 30}}>*No Comments*</Text>
                                </View>

                }
                </View>
              :
              <View style={styles.loading}>
                <Text style={styles.loadingText}>Loading...</Text>
              </View>
              }                                                                             
            </View>           

            </ScrollView>

                  <SafeAreaView style={{flex:1, width: '100%',
              alignItems: 'center',
              justifyContent: 'center',}}>
              <View style={styles.inputLayout}>
                  <View style={styles.sectionBottomCommentInput}>                                                 
                    <TextInput style={styles.sectionBottomInput} placeholder="Add a Comment..." multiline value={comments} onChangeText={(comments) => setComments(comments)} ref={inputRef}></TextInput>                           
                    <TouchableOpacity onPress={handleCommentSend} style={styles.sectionBottomSend} ><FontAwesome name='send' size={25} color='gray' /></TouchableOpacity>
                  </View>                         
              </View>
            </SafeAreaView> 
                  </View>                                                                      
    </KeyboardAwareScrollView>          
  );
}

export default ViewComments;


const styles = StyleSheet.create({
  containerOutline: {               
    width: '100%',             
    flex: 1,          
    flexDirection: 'column',      
    justifyContent: 'center',                 
  },
  container: {               
    width: '100%',        
  },    
    sectionImage: {
      width: '100%',
      height: 320,
      resizeMode: 'contain',
    },                        
    content: {        
      fontFamily: 'Poppins-Regular'
    },
    sectionTopText: {
      paddingLeft: 5,
      paddingRight: 5,
      paddingTop: 0,
      paddingBottom: 0,
      fontFamily: 'Poppins-Regular',
    },
    sectionTopTextSmall: {
      paddingLeft: 5,
      paddingRight: 5,
      paddingTop: 0,
      paddingBottom: 0,
      fontSize: 12,
      color: 'gray',
      fontFamily: 'Poppins-Regular',
    },    
    sectionTopDateSmall: {
      paddingLeft: 10,
      paddingRight: 10,
      paddingTop: 10,
      paddingBottom: 0,
      fontSize: 12,
      color: 'gray',
      fontFamily: 'Poppins-Regular',
    },
    sectionTopTextBig: {
      paddingLeft: 10,
      paddingRight: 10,
      paddingTop: 0,
      paddingBottom: 0,
      fontSize: 16,
      color: '#000',
      fontFamily: 'Poppins-Regular',
    },
    titleTag: {    
      backgroundColor: '#fff',              
      marginTop: 30,
      marginBottom: 30,
      marginLeft: 10,
      marginRight: 10,
      paddingLeft: 10,  
      paddingRight: 10,
      paddingTop: 10,
      paddingBottom: 10,
      borderRadius: 100/10,      
      shadowColor: "gray",
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5,       
    }, 
    headerButtonsContainer: {
      flexDirection:'row',        
      paddingLeft: 5,  
      paddingRight: 5,
      alignItems: 'center',          
    },
    headerButtons: {
      padding: 10,
      color: '#1C9E0B',      
    },
    sectionImageOutline: {
      width: '100%',
      height: 250,              
    },
    sectionImage: {
      width: '100%',
      height: 240,        
      alignContent: 'center',
      alignItems: 'center',        
    },            
    commentInline: {
      justifyContent: 'space-between',
      flex: 1,
      flexDirection:'row',
      padding: 10,
      paddingTop: 5,
      paddingBottom: 5,
    },
    moreComments: {
      padding:10,
      paddingTop: 2,
      paddingBottom: 2,
      fontSize: 12,
      fontFamily: 'Poppins-Regular',
    },
    loading: {        
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',        
    },
    loadingText: {    
      padding: 20,
      fontSize: 18,
      color: 'gray',
      fontFamily: 'Poppins-Regular'
    },
    comments: {
      flexDirection:'row',             
      padding: 5,    
      width: '100%'        
    },
    image: {
      width: 50,
      height: 50,
      borderRadius: 50
    },       
    commentContent: {
      marginTop: -10,        
      padding: 10,
      fontFamily: 'Poppins-Regular',
      width: '100%'
    }, 
    commentInlineData: {        
      flex: 1,        
      flexDirection:'row',       
      paddingTop: 2,
      paddingBottom: 2,
    },      
    commentTextLeft: {        
      fontSize: 14,
      color: '#000',        
      fontFamily: 'Poppins-Regular',        
    },
    commentTextRight: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',                
      paddingTop: 2,
    },
    commentText: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',
      width: '85%',            
    },
    commentTextLeftComment: {        
      fontSize: 12,
      color: 'gray',        
      fontFamily: 'Poppins-Regular',
      width: '100%',      
      padding: 10  
    },
    inputLayout: {
      justifyContent: 'center',
      alignItems: 'center',                  
      paddingTop: 10, 
      paddingBottom: 10, 
      position: 'absolute',
      bottom: 0,
      width: '100%',
      backgroundColor: '#fff'
    },
    sectionBottomCommentInput: {
      flex: 1,
      flexDirection:'row',
      justifyContent: 'center',
      alignItems: 'center',   
      width:'95%',
      padding: 5,
      borderColor: 'gray',
      borderWidth: 1,
      borderRadius: 15,          
               
    },
    sectionBottomInput: {
      padding:5,
      fontFamily: 'Poppins-Regular',        
      width:'90%',      
      backgroundColor: '#fff'
    },
    sectionBottomSend: {        
      padding:7,
      fontFamily: 'Poppins-Regular',        
      width:'10%',            
      backgroundColor: '#fff'
    },
    buttonCorner: {
      position: 'absolute',
      top: '1%',
      left: '85%',
      padding: 20,        
    },
});