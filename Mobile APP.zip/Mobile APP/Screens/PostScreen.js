import React, { useState, useEffect } from 'react';
import { AsyncStorage, StyleSheet, View, Text, Picker, Switch, CheckBox, Image, TouchableOpacity, ImageBackground, TouchableWithoutFeedback, Modal, Keyboard, TextInput, KeyboardAvoidingView, ScrollView} from 'react-native';
import * as ImagePicker from "expo-image-picker";
import { useDispatch, useSelector } from 'react-redux';
import { postPost } from "../store/actions/feedActions";
import moment from 'moment';
import 'firebase/firestore';
import {firestore} from '../Config/Config';
import {storage} from '../Config/Config';
//import { Alert } from 'react-native';

import { Alert } from 'react-native';

import { mypostData } from "../store/actions/profileActions";
function PostScreen({ navigation }) {
  
  const dispatch = useDispatch();
  const selector = useSelector(state => state);

  const [title, setTitle] = useState("");
  const [labelTitle, setLabelTitle] = useState("");
  const [color, setColor] = useState("#000");
  const [backgroundColor, setBackgroundColor] = useState("#fff");
  const [borderBottomColor, setBorderBottomColor] = useState("gray");
  
  const [location, setLocation] = useState("");
  const [labelLocation, setLabelLocation] = useState("");

  const [description, setDescription] = useState("");
  const [labelDescription, setLabelDescription] = useState("");

  const [url, setUrl] = useState("");
  const [category, setCategory] = useState("Select Tag");
  const [terms, setTerms] = useState(false);
  const [phone, setPhone] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [userUid, setUserUid] = useState("");
  const [file, setFile] = useState("");
  const [name, setName] = useState("");
  const [likes, setLikes] = useState(0);
  const [commentCounter, setCommentCounter] = useState(0);
  const [deleteFlag, setDeleteFlag] = useState(false);
  const [share, setShare] = useState(true);
  const [postFlagged, setPostFlagged] = useState(false);
  const [docRefId, setDocRefId] = useState("");
  const [numberOfPosts, setNumberOfPosts] = useState("");
  const [progress, setProgress] = useState("progresss");

  const [loading, setLoading] = useState(false);
  
  useEffect(() => {       
    setLoading(false);
  },[]);

  useEffect(() => {
        setUrl('');
        setCategory('');
        setTitle('');
        setLocation('');
        setDescription('');

      chooseFilesd();
      console.log('post page loaded 1');    

      AsyncStorage.getItem('userDetail').then((currentUser_json) => {
        let currentUser = JSON.parse(currentUser_json);      
        firestore.collection('users').doc(currentUser.user.uid).get().then((doc) => {
          setPhone(doc.data().phone);
          setUsername(doc.data().username);
          setEmail(doc.data().email);
          setUserUid(doc.id);
          setNumberOfPosts(doc.data().numberOfPosts);
        });
      });
                       
  }, []);   

 let chooseFilesd = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({allowsEditing: false,
    exif: true});

    let name = result.uri.split('/').pop();
    let ext = name.split('.').pop();
    let filename = moment().unix() + phone + '.' + ext;  
    if(!result.cancelled) {
      uploadImage(result.uri, filename)
    }
  }         

 let uploadImage = async (uri, imageName) =>{
    const response = await fetch(uri);
    const blob = await response.blob();

   const ref = storage.ref().child("images/" + imageName).put(blob);
   ref.on('state_changed',
   (snapshot) => {
     // progrss function ....
     const progresss = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
     //this.setState({progress});
     setProgress(progresss);
   },
   (error) => {
        // error function ....
     console.log(error);
   },
 () => {

     // complete function ....
     storage.ref('images').child(imageName).getDownloadURL().then(url => {
       console.log(url);
       console.log(imageName);
      setName(imageName);
      setUrl(url);
     })
 });
   
  }


function onFocusTitle() {
  setColor('#000');
  setLabelTitle(true);
  setBorderBottomColor('#d3d3d3');
  setBackgroundColor('#fff');
}

function onBlurTitle() {
  setColor('#000');
  setBackgroundColor('#fff');
  setLabelTitle(false);
  setBorderBottomColor('gray');
}

function onFocusLocation() {
  setColor('#000');
  setLabelLocation(true);
  setBorderBottomColor('#d3d3d3');
  setBackgroundColor('#fff');
}

function onBlurLocation() {
  setColor('#000');
  setBackgroundColor('#fff');
  setLabelLocation(false);
  setBorderBottomColor('gray');
}

function onFocusDescription() {
  setColor('#000');
  setLabelDescription(true);
  setBorderBottomColor('#d3d3d3');
  setBackgroundColor('#fff');
}

function onBlurDescription() {
  setColor('#000');
  setBackgroundColor('#fff');
  setLabelDescription(false);
  setBorderBottomColor('gray');
}

  function toggleSwitch() {
    setShare(!share);
 }

 function Postterm() {
   alert(`Please agree 'Terms & Conditions'`);
 }
 
function Clear(){
  Keyboard.dismiss();
  setTitle('');
  setLocation('');
  setUrl('');
  setDescription('');
  setCategory('Select Tag');
  setTerms(false);
  setName('');
  setLikes(0);
  setCommentCounter(0);
  setDeleteFlag(false);
  setShare(true);
  setPostFlagged(false);
 }

  let Post = async (e) => {
    e.preventDefault();
    Keyboard.dismiss();
    const newPost = {
       userUid: userUid,
       username: username,
       email: email,
       phone: phone,
       title: title,
       location: location,
       description: description,
       url: url, 
       name: name, 
       postedUnix: moment().unix(),
       likes: likes, 
       commentCounter: commentCounter, 
       deleteFlag: deleteFlag, 
       category: category, 
       share: share, 
       postFlagged: postFlagged,
       numberOfPosts: numberOfPosts,
       flaggedBy: []
      };


      const myPost = {
        userUid: userUid,
        username: username,
        email: email,
        phone: phone,
        title: title,
        location: location,
        description: description,
        url: url, 
        imageName: name,                 
        postedUnix: moment().unix(),        
        deleteFlag: deleteFlag, 
        category: category, 
        share: share,         
        postFlagged: postFlagged,                                 
        numberOfPosts: numberOfPosts,
        /*myPostComments: [],
        myPostLikes: [],*/                   
       };


    if(url == ''){
      alert('Please upload image')
  }
  else if(category == 'Select Tag'){
    alert('Please select category')
}
  else if(title == ''){
        alert('Title can`t be empty')
    }
    else if(location == ''){
        alert('Location can`t be empty')
    }
    else if(description == ''){
        alert('Description can`t be empty')
    }
    else{
      postPost(newPost, myPost, navigation);
       // setLoading(true);      
        /*await postPost(newPost, myPost, navigation).then((response) => {
          alert("Successfuly posted.");

          alert(response.data);
          setUrl('');
          setCategory('');
          setTitle('');
          setLocation('');
          setDescription('');    
        }).catch((errro) => {
          console.log(error);          
        })*/
        /*dispatch(postPost(newPost, myPost, navigation));
          setUrl('');
          setCategory('');
          setTitle('');
          setLocation('');
          setDescription('');    */

    }
   }











const postPost = (newPost, myPost, navigation) => {
  //alert("data 1");
    let numberOfPost = newPost.numberOfPosts;
    let numberOfPosting = Number(numberOfPost)+1;
    let postedDocId;
    firestore.collection('post').add(newPost).then((docRef) => {     
      firestore.collection('post').doc(docRef.id).update({doc_id: docRef.id});
      
      postedDocId = docRef.id;
  
      console.log("Post added");
  
    }).then(() => {
      firestore.collection('users').doc(newPost.userUid).update({
        numberOfPosts : numberOfPosting,            
      }).then(()=>{     
  
        console.log("number of posting updated in users");
  
        //MyPost add in users list           
        firestore.collection('users').doc(newPost.userUid).set({
          myPost: {
            [postedDocId]: myPost,
          },
        }, { merge: true }).then(()=>{  
          firestore.collection('users').doc(newPost.userUid).set({
              myPost: {
                [postedDocId]: {doc_id: postedDocId},
              },
            }, { merge: true });
  
          console.log("Post details updated in users");
        //MyPost comments count add in users list
        firestore.collection('users').doc(newPost.userUid).set({
          myPostCommentsCount: {
            [postedDocId]: 0,
          },
        }, { merge: true }).then(()=>{  
          console.log("update comments count in users");
          //Mypost likes count add in users list                                            
          firestore.collection('users').doc(newPost.userUid).set({              
            myPostLikesCount: {
              [postedDocId]: 0,
             },

          }, { merge: true }).then(()=>{  
            console.log("update likes count in users");
            firestore.collection('countComments').doc('noOfComments').set({ [postedDocId]: 0 }, { merge: true }).then(()=>{ 
              console.log("update count comment in seprately");
            firestore.collection('countLikes').doc('noOfLikes').set({ [postedDocId]: 0 }, { merge: true }).then(()=>{ 
              console.log("update count like in seprately");                                            
                  console.log("successfully posted");
                  //alert("successfuly posted");
                 // return true;          
                 setUrl('');
                 setCategory('');
                 setTitle('');
                 setLocation('');
                 setDescription('');  
                 dispatch(mypostData(userUid, {dispatch}));                       
                 Alert.alert(
                  'Post',
                  'Successfuly posted.',
                  [
                    {text: 'OK', onPress: () => navigation.navigate('ProfileTab')},
                  ],
                  { cancelable: false }
                );


            });
            });
          }); 
        });    
        
      })            
      })
    }).catch(error => 
          {
          console.log("Error");
          dispatch({
              type: GET_ERRORS,
              payload: error
            })
          }
          )
      
    };
  












  

  return (    
    <View style={styles.container}>
         <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <Text></Text>
      <View>
      {url == '' ?
         
         <View style={{width: '100%', height: 220, justifyContent: 'center',alignItems: 'center' }}>

           <ImageBackground imageStyle={{ borderRadius: 20 }} source={require('../assets/background.jpg')} 
                 style={{width: '96%', height: 220, alignSelf: 'center' }}>
                 <View style={{flex: 1,justifyContent: 'flex-end',alignItems: 'flex-end'}}>
                   <TouchableOpacity  onPress={chooseFilesd} >
                       <Image
                         source={require('../assets/Changeimg.png')}
                         style={{width: 40 , height: 40 ,alignItems: 'center',justifyContent: 'center',borderWidth: 1,borderColor: '#fff',borderRadius: 30}} />
                   </TouchableOpacity>
                 </View>
           </ImageBackground>

           </View>
           :
           <View style={{width: '100%', height: 220, justifyContent: 'center',alignItems: 'center' }}>
             <ImageBackground imageStyle={{ borderRadius: 20 }} source={{uri: url}} style={{width: '96%', height: 220, alignSelf: 'center' }}>
                   <View style={{flex: 1,justifyContent: 'flex-end',alignItems: 'flex-end'}}>
                   <TouchableOpacity  onPress={chooseFilesd} >
                         <Image
                         source={require('../assets/Changeimg.png')}
                         style={{width: 40 , height: 40 ,alignItems: 'center',justifyContent: 'center',borderWidth: 1,borderColor: '#fff',borderRadius: 30}} />
                   </TouchableOpacity>
                   </View>
             </ImageBackground>
           </View>
         }


      {labelTitle ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Caption</Text> : 
          <View>{title.length > 0 ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Caption</Text> : 
            <Text style={{color: '#fff', fontFamily: 'Poppins-Regular',}}>Caption</Text>}</View>}
            <TextInput onBlur={onBlurTitle} onFocus={onFocusTitle} 
            style={{ height:50, backgroundColor: backgroundColor, color: color, borderBottomColor: borderBottomColor, borderBottomWidth: 1, fontFamily: 'Poppins-Regular' }}
            placeholder={labelTitle ? '': 'Caption'}
             value={title} onChangeText={title => setTitle(title)}  />   

      {category === 'Select Category' ?
              null
              :
              <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Category</Text>
      }
     <View style={{height: 45, borderBottomColor: 'black', borderBottomWidth: 1}}>

          <Picker selectedValue={category} itemStyle={{ backgroundColor: "gray", color: "blue" }}
              style={{height: 45, color: '#000'}}
              textStyle={{fontFamily: 'Poppins-Regular'}}
              itemTextStyle={{fontFamily: 'Poppins-Regular'}}
              onValueChange={(itemValue, itemIndex) =>
              setCategory(itemValue)
              }>          
          <Picker.Item label="Select Category" value="Select Category" />
          <Picker.Item label="Traffic Violence" value="Traffic Violence" />
          <Picker.Item label="Law and order" value="Law and order" />
          <Picker.Item label="Electricity" value="Electricity" />
          <Picker.Item label="Sewage" value="Sewage" />
          <Picker.Item label="Solid Waste" value="Solid Waste" />
          <Picker.Item label="Health" value="Health" />
          </Picker>
      </View>         

      {labelLocation ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Location</Text> : 
          <View>{location.length > 0 ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Location</Text> : 
          <Text style={{color: '#fff', fontFamily: 'Poppins-Regular',}}>Location</Text>}</View>}
          <TextInput onBlur={onBlurLocation} onFocus={onFocusLocation} 
          style={{ height:50, backgroundColor: backgroundColor, color: color, borderBottomColor: borderBottomColor, borderBottomWidth: 1, 
          fontFamily: 'Poppins-Regular', }} placeholder={labelLocation ? '': 'Location'} 
          value={location} onChangeText={(location) => setLocation(location)} />                    

      {labelDescription ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Description</Text> : 
          <View>{description.length > 0 ? <Text style={{color: 'gray', fontFamily: 'Poppins-Regular',}}>Description</Text> : 
          <Text style={{color: '#fff', fontFamily: 'Poppins-Regular',}}>Description</Text>}</View>}
          <TextInput onBlur={onBlurDescription} onFocus={onFocusDescription} 
          style={{ height:70, backgroundColor: backgroundColor, color: color, borderBottomColor: borderBottomColor, borderBottomWidth: 1, fontFamily: 'Poppins-Regular', }} 
          multiline placeholder={labelDescription ? '': 'Description'}
           value={description} onChangeText={(description) => setDescription(description)}/>                                       
  
          <View style={styles.share}>                    
            <Text style={{fontFamily: 'Poppins-Regular',}}>Private post</Text>                                                                
            <Switch
            trackColor={{true: '#b3b3b3', false: '#262626'}}
            thumbColor={share == true ? '#b3b3b3' : '#262626'}
            onValueChange={toggleSwitch}
            value = {share}/>
          </View>                

          <View style={styles.terms}>
            <CheckBox value={terms} onChange={ e => setTerms(!terms)} />
            <Text style={{alignSelf:'center', textAlign:'center', fontFamily: 'Poppins-Regular',}} >Agree Terms & Conditions</Text>
          </View>


      <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 50, paddingBottom: 50, flexDirection: 'row' }}>  
      {terms == false?
          <TouchableOpacity onPress={Postterm}>  
          <View>                      
            <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center',}} />
            <Text style={styles.buttonCentered1}>Publish</Text>                            
          </View>
          </TouchableOpacity>

          :
          <TouchableOpacity onPress={Post}>
          <View>                      
            <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center',}} />
            <Text style={styles.buttonCentered1}>Publish</Text>
          </View>
          </TouchableOpacity>                        
       }
       <View>          
        <TouchableOpacity onPress={Clear}>
        <View>                      
          <Image source={require('../assets/cancel.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
          <Text style={styles.buttonCentered}>Clear</Text>
        </View>
        </TouchableOpacity>                        
        </View>                          
       </View>

       {/*<View>
              {loading?
                <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 50, paddingBottom: 50, flexDirection: 'row' }}>                              
                  <Text style={{color:'gray', textAlign: 'center', fontSize: 18, padding: 20, fontFamily: 'Poppins-Regular',}}><Text style={{color: 'gray', fontWeight: 'bold', textAlign: 'center', fontFamily: 'Poppins-Regular',}} >&nbsp;Loading to post...</Text></Text>                             
                </View>       
                :
                <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 50, paddingBottom: 50, flexDirection: 'row' }}>  
                    {terms == false?
                        <TouchableOpacity onPress={Postterm}>  
                        <View>                      
                          <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center',}} />
                          <Text style={styles.buttonCentered1}>Publish</Text>                            
                        </View>
                        </TouchableOpacity>

                        :
                        <TouchableOpacity onPress={Post}>
                        <View>                      
                          <Image source={require('../assets/Button-Bg.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center',}} />
                          <Text style={styles.buttonCentered1}>Publish</Text>
                        </View>
                        </TouchableOpacity>                        
                    }
                    <View>          
                      <TouchableOpacity onPress={Clear}>
                      <View>                      
                        <Image source={require('../assets/cancel.png')} style={{width: 120, height: 45, justifyContent: 'center', alignItems: 'center'}} />
                        <Text style={styles.buttonCentered}>Clear</Text>
                      </View>
                      </TouchableOpacity>                        
                      </View>                          
              </View>
              }
      </View>*/}
       {/*<View>
              {loading?
                <View style={styles.contentInput}>                              
                  <Text style={{color:'gray', textAlign: 'center', fontSize: 12, padding: 10, fontFamily: 'Poppins-Regular',}}><Text style={{color: 'gray', fontWeight: 'bold', textAlign: 'center', fontFamily: 'Poppins-Regular',}} >&nbsp;Loading to post...</Text></Text>                             
                </View>       
                :
                null
              }
      </View>*/}


       <Text></Text>

      </View> 
      </ScrollView>
      </View>    
    );
  }

export default PostScreen;

const styles = StyleSheet.create({
  container: {
      flex: 1,
      backgroundColor: '#fff',    
      alignItems: 'stretch',
      justifyContent: 'center',      
      paddingLeft: 20,
      paddingRight: 20,
      flexDirection: 'column',      
  },
  share: {
    padding: 10,
      flexDirection: 'row',
      justifyContent: 'center',
      alignContent: 'center'
},
terms: {
  padding: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignContent: 'center'
},
buttonCentered1: {
  position: 'absolute',
  top: '28%',
  left: '32%',
  color: '#000',
  fontWeight: 'bold',    
  fontFamily: 'Poppins-Regular',
},
buttonCentered: {
  position: 'absolute',
  top: '30%',
  left: '37%',
  color: '#000',
  fontWeight: 'bold',    
  fontFamily: 'Poppins-Regular',
},
})