import React, { useState, useEffect } from 'react';
import {AsyncStorage, Modal, TouchableWithoutFeedback, TouchableHighlight, ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, KeyboardAvoidingView, FlatList} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesome } from "react-native-vector-icons";
import moment from 'moment';
import ReadMore from 'react-native-read-more-text';
import ImageViewer from 'react-native-image-zoom-viewer';
import { RefreshControl } from 'react-native';
import Icon from 'react-native-vector-icons/Entypo';

import { feedData, likeUpdate, dislikeUpdate, likeData, commentsData, getProfilePicture} from "../store/actions/feedActions";

import { LIKES_DATA } from "../store/actions/actionTypes";

import 'firebase/firestore';
import { firestore } from '../Config/Config';
import * as firebase from 'firebase';

function Feed({ navigation }) {

  const dispatch = useDispatch();
  const selector = useSelector(state => state);
  
  const [userId, setUserId] = useState('');
  const [phone, setPhone] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
   
  const [key, setKey] = useState(null);  
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible1, setModalVisible1] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const [userUID, setUserUID] = useState('');
  const [reportedFlag1, setReportedFlag1] = useState('');
  const [doc_idtest, setDoc_idtest] = useState('');
  const [postFlagged, setPostFlagged] = useState('');
  const [flaggedDetails, setFlaggedDetails] = useState([]); 

useEffect(() => {     
  const getUserData = async () => {      
    await AsyncStorage.getItem('userDetail').then((user_data_json) => {
      let userData = JSON.parse(user_data_json);         
      if (userData != null) {                      
        console.log('Feed page loaded 1');
        let userId = userData.user.uid;                   
        firestore.collection('users').doc(userId).get().then((doc) => {
          if(doc.data().status == 'active'){            
            setUserId(doc.id);
            setPhone(doc.data().phone);
            setUsername(doc.data().username);
            setEmail(doc.data().email);                    
          }            
        })
      }   
    });
  }

  getUserData(); 

 },[userId]);
  

useEffect(() => {   
  console.log('Feed page loaded 2');
  if(userId){
    dispatch(feedData(userId));  
  }
},[userId]);


useEffect(() => {   
  dispatch(getProfilePicture());    
},[]);

useEffect(() => {   
  dispatch(likeData());      
},[]);


useEffect(() => {   
  dispatch(commentsData());    
},[]);

const dateformat = (date) => {
  var postDate = moment.unix(date);
  var data = moment(postDate).startOf('minute').fromNow();        
  return data;
};

const _handleTextReady = () => {}
  
const Capitalize = (str) => {
     return str.charAt(0).toUpperCase() + str.slice(1);
}

const viewComments = (person) => {            
    navigation.navigate('ViewComments', {
      person: person,            
    });  
}
    
const setModalVisibles = (visible, i) => {        
    setModalVisible(visible);
    setKey(i);   
}

const setModalVisibles1 = (visible, data, data1, data2, data3) => {
  setModalVisible1(!modalVisible1);   
  setDoc_idtest(data);   
  setUserUID(data1);    
  setPostFlagged(data2);     
  setFlaggedDetails(data3);              
}
const reportAuthoring = (person, doc_idtest) => {   
    setModalVisible1(!modalVisible1);    
    /*props.navigation.navigate('ReportAuthoring', {
        doc_idtest: doc_idtest,    
        person: person                    
    }); */
}


const flagInapp = (doc_idtest) => {  
  // alert(doc_idtest);
       setModalVisible1(!modalVisible1);    
       navigation.navigate('FlagAsInappropriate', {
           doc_idtest: doc_idtest,            
         });  
 }
  
const likeButton = (item, likes) => {  

  let likePayload = {
    likeCount: {...selector.FeedPage.likesData, [item.doc_id]: likes+1},
    likedUser: {...selector.FeedPage.likesDataList, [item.doc_id]: 'active'}
  }        
  dispatch({
    type: LIKES_DATA,      
    payload: likePayload
  });
  likeUpdate(item, userId, username, email, phone, likes, dispatch);   

}

const dislikeButton = (item, likesCount) => {  

  let likePayload = {
    likeCount: {...selector.FeedPage.likesData, [item.doc_id]: likesCount-1},
    likedUser: {...selector.FeedPage.likesDataList, [item.doc_id]: 'inactive'}
  }        
  dispatch({
    type: LIKES_DATA,      
    payload: likePayload
  });  
  dislikeUpdate(item, userId, username, email, phone, likesCount, dispatch);  

}

  return (
    <KeyboardAvoidingView behavior="position" enabled style={styles.containerOutline}  keyboardVerticalOffset={50}>          
      <ScrollView style={styles.container} refreshControl={<RefreshControl refreshing={selector.FeedPage.isFetching} />}>                              
        

{selector.FeedPage.datasLength == '1' ? 
              <View>                
                {(selector.FeedPage.datas.length > 0 && selector.FeedPage.datas.length != null) ?
                <View style={{flex: 1}}>
              <FlatList  
                    extraData={selector.FeedPage.datas}  
                    data={selector.FeedPage.datas}                                                          
                    renderItem={({item, index}) =>  
                    <View style={styles.sectionoutline} key={index}>           
                
                    <View style={styles.sectionTopOutline}>                
                      <View style={styles.sectionTopNameScetion}>                                                   
                          <View style={styles.groupleft}>                          
                            <View style={styles.profileImage}>
                            {selector.FeedPage.profileUrls ?
                              <View>
                                {selector.FeedPage.profileUrls[item.userUid]?                                    
                                  <Image source={{uri: selector.FeedPage.profileUrls[item.userUid]}} style={styles.image} />                                  
                                  : 
                                  <Image source={require('../assets/pp.png')} style={styles.image} />
                                }
                              </View>
                             : 
                              <Image source={require('../assets/pp.png')} style={styles.image} />
                            }
                            </View>        
                        
                            <View style={styles.groupText}>                           
                              <Text style={styles.sectionTopTextSmall}>{Capitalize( item.username )}</Text>   
                              <Text style={styles.sectionTopTextSmall}>{item.category}</Text>     
                            </View>          
                          </View>   
                          <View style={styles.groupText}>
                            <Text style={styles.sectionTopTextSmall}>{dateformat(item.postedUnix)}</Text>
                            <Text style={styles.sectionTopLocation}>{item.location}</Text>
                          </View>
                      </View>

                      <Text style={styles.sectionTopTextBig}>{ item.title || 'Loading' }</Text>
                      

                      <View style={styles.sectionBottomLikeComment}>
                        <View style={styles.card}>
                          <ReadMore
                            numberOfLines={2}
                            onReady={_handleTextReady}>
                            <Text style={styles.cardText}>
                            {item.description}
                            </Text>
                          </ReadMore>
                        </View>
                      </View>
                      
                    </View>                                                             

                    <TouchableHighlight
                      onPress={() => {
                        setModalVisibles(true, index);                            
                      }}>
                        <View style={styles.sectionImageOutline}>  

                        <Image source={{uri: item.url}}  style={styles.sectionImage} />  

                        <TouchableOpacity onPress={() => setModalVisibles1(!modalVisible1, item.doc_id, item.userUid, item.postFlagged, item.flaggedBy)} style={styles.buttonCorner}>
                          <Icon name="dots-three-vertical" size={20} color="#fff" />
                    </TouchableOpacity>
                 
                    <Modal
                      animationType=""
                      transparent={true}
                      animationInTiming={0}
                      visible={modalVisible1}
                      onRequestClose={() => {
                    alert('Modal has been closed.');                    
                    }}>

                    <TouchableWithoutFeedback style={{backgroundColor: 'red'}}
                                          onPress={() => setModalVisibles1(!modalVisible1)}>
                    
                    <View style={{
                            flex: 1,
                            /*backgroundColor: 'rgba(52, 52, 52, 0.1)',*/                            
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            left: 0,
                            bottom: 0
                        }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'column',
                        backgroundColor: '#fff',
                        borderRadius: 2,
                        shadowRadius: 10,
                        marginTop: 350,
                    }}>
                      
                    <View style={{ height: 300 }}>
                         
                    <View>                
                    {postFlagged == true?
                      null
                    :   
                    <View>
                      {flaggedDetails == 0?
                        <TouchableOpacity onPress={flagInapp.bind(this, doc_idtest)}>
                        <View style={{marginTop: 10, alignItems: 'center', borderBottomColor: '#bfbfbf', borderBottomWidth: 1}}>
                            <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray', paddingTop: 10, paddingBottom: 10}}>Flag as inappropriate</Text>
                        </View>
                        </TouchableOpacity>
                        :
                        <View>
                        {flaggedDetails[phone] && flaggedDetails[phone].flaggedPhone == phone?
                          <TouchableOpacity onPress={flagInapp.bind(this, doc_idtest)}>
                          <View style={{marginTop: 10, alignItems: 'center', borderBottomColor: '#bfbfbf', borderBottomWidth: 1}}>
                              <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray', paddingTop: 10, paddingBottom: 10}}>Flag as inappropriate</Text>
                          </View>
                          </TouchableOpacity>
                          :
                          null
                        }
                        </View>                              
                      }
                     </View>
                    }
                    </View>
                    <TouchableOpacity onPress={() => setModalVisibles1(!modalVisible1)}>
                        <View style={{marginTop: 10, alignItems: 'center' }}>                        
                          <Text style={{ fontFamily: 'Poppins-Regular', fontSize: 16, color: 'gray'}}>Cancel</Text>                                
                        </View>
                    </TouchableOpacity>                            
                    </View>
                    </View>                        
                    </View>
                    </TouchableWithoutFeedback>
                    </Modal>  
                    </View>
                    </TouchableHighlight>
                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={key == index ? modalVisible : false}
                        style={{ backgroundColor: '#000' }}
                        onRequestClose={() => {                             
                         setModalVisibles(!modalVisible, null); 
                        }}>
                        
                    <View style={styles.containerFull} >
                    <TouchableHighlight
                        style={{flexDirection: 'row', justifyContent: 'flex-start', padding:10}}
                        onPress={() => {
                          setModalVisibles(!modalVisible, null);                                    
                        }}>                              
                           <View style={{width: '100%', height: 50}}><Image source={require('../assets/Close.png')} style={{width: 15, height: 15}} /></View>
                    </TouchableHighlight>                              
                          
                    <ImageViewer imageUrls={[{url: item.url}]} renderIndicator={() => null} style={styles.sectionImageFull} />
                    </View>                        
                    </Modal>    

                    <View style={styles.sectionBottomOutline}>                
                    <View style={styles.sectionBottomLikeComment}>  
                      


                    <View>
                      {selector.FeedPage.likesData[item.doc_id] == 0?                                  
                      <View>
                        <TouchableOpacity onPress={() =>likeButton(item, selector.FeedPage.likesData[item.doc_id])}><Text style={styles.sectionBottomText}><FontAwesome name='thumbs-o-up' size={20} color='gray' /> {selector.FeedPage.likesData[item.doc_id]} Likes</Text></TouchableOpacity>
                      </View>
                      :
                      <View>
                        {selector.FeedPage.likesDataList?    
                          <View>
                            {selector.FeedPage.likesDataList[item.doc_id] && selector.FeedPage.likesDataList[item.doc_id] == "active"?                                  
                              <TouchableOpacity onPress={() => dislikeButton(item, selector.FeedPage.likesData[item.doc_id])}><Text style={styles.sectionBottomText}><FontAwesome name='thumbs-up' size={20} color='gray' /> {selector.FeedPage.likesData[item.doc_id]} Likes</Text></TouchableOpacity>
                              :                                    
                              <TouchableOpacity onPress={() => likeButton(item, selector.FeedPage.likesData[item.doc_id])}><Text style={styles.sectionBottomText}><FontAwesome name='thumbs-o-up' size={20} color='gray' /> {selector.FeedPage.likesData[item.doc_id]} Likes</Text></TouchableOpacity>
                            }
                          </View>                                                      
                        :                                    
                        <TouchableOpacity onPress={() => likeButton(item, selector.FeedPage.likesData[item.doc_id])}><Text style={styles.sectionBottomText}><FontAwesome name='thumbs-o-up' size={20} color='gray' /> {selector.FeedPage.likesData[item.doc_id]} Likes</Text></TouchableOpacity>
                        }                        
                      </View>
                      }
                      </View>                                        
                      
                      <TouchableOpacity onPress={viewComments.bind(this, item)}>
                        <Text style={styles.sectionBottomText}>View {selector.FeedPage.commentsCountData[item.doc_id]} Comments</Text>
                      </TouchableOpacity>
                      
                      </View>                                                                                                                                               
                    </View>     
                                                                      
                  </View>       
                  
                  }  
                
                ItemSeparatorComponent={null}
                />  

                </View>
                :
                <View style={styles.loading}>                  
                  <Text style={styles.loadingText}>No Posts are found.</Text>
                </View>
                }
              </View>          
              :
              <View style={styles.loading}>
                <Text style={styles.loadingText}>{/*Loading...*/}</Text>
              </View>
              }  
      </ScrollView>
    </KeyboardAvoidingView>     
  );
}

export default Feed;


const styles = StyleSheet.create({
   
    containerOutline: {               
        width: '100%',                
        backgroundColor: '#fff',                
        backgroundColor: '#d3d3d3',
        flex: 1,    
        flexDirection: 'column',
        alignItems: 'stretch',
        justifyContent: 'center',                    
      },
      container: {               
        width: '100%',
        paddingBottom: 50,
        backgroundColor: '#fff',                
        backgroundColor: '#d3d3d3',
      },
      loading: {        
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',        
      },
      loadingText: {    
        padding: 20,
        fontSize: 18,
        color: 'gray',
        fontFamily: 'Poppins-Regular'
      },
      card: {
        marginHorizontal: 10,
        padding: 0,
        borderRadius: 3,                
      },
      cardText: {
        fontSize: 12,
        color: 'gray',        
        textAlign: 'justify',
        fontFamily: 'Poppins-Regular',
      },
      content: {        
        fontFamily: 'Poppins-Regular'
      },
      sectionoutline: {        
        marginBottom: 5,                
      },      
      sectionTopOutline: {        
        backgroundColor: '#fff',
        padding:5,
        paddingTop: 10,
      },
      sectionTopNameScetion: {
        justifyContent: 'space-between',
        flex: 1,
        flexDirection:'row',
      },
      sectionTopText: {
        paddingLeft: 5,
        paddingRight: 5,
        paddingTop: 0,
        paddingBottom: 0,
        fontFamily: 'Poppins-Regular',
      },
      sectionTopTextSmall: {
        paddingLeft: 5,
        paddingRight: 5,
        paddingTop: 0,
        paddingBottom: 0,
        fontSize: 12,
        color: 'gray',
        fontFamily: 'Poppins-Regular',
      },    
      sectionTopDateSmall: {
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 10,
        paddingBottom: 0,
        fontSize: 12,
        color: 'gray',
        fontFamily: 'Poppins-Regular',
      },
      sectionTopLocation: {
        paddingLeft: 5,
        paddingRight: 5,
        paddingTop: 0,
        paddingBottom: 0,
        textAlign: 'right',
        fontSize: 12,
        color: 'gray',
        fontFamily: 'Poppins-Regular',
      },  
      sectionTopTextBig: {
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 0,
        paddingBottom: 0,
        fontSize: 16,
        color: '#000',
        fontFamily: 'Poppins-Regular',
      },
      groupleft: {
        flexDirection:'row',             
        padding: 5,    
        
      },
      groupText: {
        marginTop: -5,
        padding: 10,        
      },
      image: {
        width: 50,
        height: 50,
        borderRadius: 50
      },      
      sectionImageOutline: {
        width: '100%',
        height: 250,
        padding: 10,        
        backgroundColor: '#fff',
      },
      sectionImage: {
        width: '100%',
        height: 240,
        padding: 10,
        borderRadius: 20,
        alignContent: 'center',
        alignItems: 'center',        
      },
      containerFull: {                 
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',                
        width: '100%',
        height: 'auto',
        minHeight: 500,
        maxHeight: 'auto',        
        paddingBottom: 30,
        backgroundColor: '#000',                
      },
      sectionImageFull: {
        width: '100%',
        height: 320,
        resizeMode: 'contain',
        backgroundColor: '#000',                
      },
      sectionBottomOutline: {
        backgroundColor: '#fff',
        padding: 0,
        paddingBottom: 5,
      },
      sectionBottomLikeComment: {
        justifyContent: 'space-between',
        flex: 1,
        flexDirection:'row',
      },
      sectionBottomText: {
        padding:10,
        color: 'gray',
        fontFamily: 'Poppins-Regular',
      },      
      sectionBottomTextComment: {
        padding:10,
        paddingTop: 2,
        paddingBottom: 2,
        fontFamily: 'Poppins-Regular',
      },
      inputLayout: {
        justifyContent: 'center',
        alignItems: 'center',           
      },
      sectionBottomCommentInput: {
        flex: 1,
        flexDirection:'row',
        justifyContent: 'center',
        alignItems: 'center',   
        width:'95%',
        padding: 5,
        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 15,    
                 
      },
      sectionBottomInput: {
        padding:5,
        fontFamily: 'Poppins-Regular',        
        width:'90%',
        backgroundColor: '#fff'
      },
      sectionBottomSend: {        
        fontFamily: 'Poppins-Regular',        
        width:'10%',
        backgroundColor: '#fff'
      },
      commentInline: {
        justifyContent: 'space-between',
        flex: 1,
        flexDirection:'row',
        padding: 10,
        paddingTop: 5,
        paddingBottom: 5,
      },
      commentTextLeft: {        
        fontSize: 14,
        color: '#000',        
        fontFamily: 'Poppins-Regular',
      },
      commentTextLeftComment: {        
        fontSize: 12,
        color: 'gray',        
        fontFamily: 'Poppins-Regular',
        width: '100%',        
      },
      commentTextRight: {        
        fontSize: 10,
        color: 'black',        
        fontFamily: 'Poppins-Regular',        
      },
      moreComments: {
        padding:10,
        paddingTop: 2,
        paddingBottom: 2,
        fontSize: 12,
        fontFamily: 'Poppins-Regular',
      },
      buttonCorner: {
        position: 'absolute',
        top: '10%',
        left: '85%',
        padding: 20,        
      },
      bottomNavigationView: {
        backgroundColor: '#fff',
        width: '100%',
        height: 140,
      },
});
