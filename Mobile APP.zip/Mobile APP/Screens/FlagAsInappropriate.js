import React, { useState, useEffect } from 'react';
import {AsyncStorage, ImageBackground, Keyboard, TextInput, ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, KeyboardAvoidingView} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesome } from "react-native-vector-icons";
import moment from 'moment';
import { flagPost } from "../store/actions/feedActions";
import 'firebase/firestore';
import { firestore } from '../Config/Config';

// A screen!
function FlagAsInappropriate({ navigation, route }) {
  const dispatch = useDispatch();
  const selector = useSelector(state => state);

  const [title, setTitle] = useState(false);
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [category, setCategory] = useState("Select Tag"); 
  const [postedUnix, setPostedUnix] = useState(false);
  const [doc_id, setDoc_id] = useState("");
  const [flaggedReason, setFlaggedReason] = useState("");
  const [flaggedBy, setflaggedBy] = useState("");
  const [flaggedEmail, setflaggedEmail] = useState("");
  const [flaggedUid, setflaggedUid] = useState("");
  const [flaggedPhone, setflaggedPhone] = useState("");
  const [userUid, setUserUid] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [adminFlag, setAdminFlag] = useState(false);
  const [noOfReportedPosts, setNoOfReportedPosts] = useState("");
  const [noOfPostReportedByHim, setNoOfPostReportedByHim] = useState("");
  
useEffect((selector) => {  
 // alert(route.params.doc_idtest)
  console.log('Flag page loaded 1');
  const getUserData = async () => {  
    
    await AsyncStorage.getItem('userDetail').then((user_data_json) => {
      let userData = JSON.parse(user_data_json);         
      if (userData != null) {                      
        let userId = userData.user.uid;                   
        firestore.collection('users').doc(userId).get().then((doc) => {
          if(doc.data().status == 'active'){            
            setflaggedUid(doc.id);
            setflaggedPhone(doc.data().phone);
            setflaggedBy(doc.data().username);
            setflaggedEmail(doc.data().email);   
            setNoOfPostReportedByHim(doc.data().noOfPostReportedByHim);                 
          }            
        })
      }   

  });

  }

  firestore.collection('post').doc(route.params.doc_idtest).get().then((docs) => {
          
    if(docs.exists){
      setCategory(docs.data().category);
      setTitle(docs.data().title);
      setLocation(docs.data().location);
      setDescription(docs.data().description);
      setUrl(docs.data().url);
      setDoc_id(docs.data().doc_id);
      setUserUid(docs.data().userUid);
      setUserPhone(docs.data().phone);
      setUserName(docs.data().username);
      setUserEmail(docs.data().email);
      setPostedUnix(docs.data().postedUnix);

      firestore.collection('users').doc(docs.data().userUid).get().then((docss) => {
        if(docss.exists){ 
        setNoOfReportedPosts(docss.data().noOfReportedPosts);             
        }
      })
    }

  })



  getUserData(); 
 },[]);
  
 
  const _handleTextReady = () => {
    }
  
  let Post = e => {
        e.preventDefault();
        Keyboard.dismiss();

        const flaggedPost = {
            flagged_post_id: doc_id,
            category: category,
            title: title,
            location: location,
            description: description,
            url: url,            
            flaggedBy: flaggedBy,
            flaggedEmail: flaggedEmail,
            flaggedUid: flaggedUid,
            flaggedPhone: flaggedPhone,
            userUid: userUid,
            userPhone: userPhone,
            userName: userName,
            userEmail: userEmail,
            flaggedUnix: moment().unix(),
            postedUnix: postedUnix,
            adminFlag: adminFlag,
            flaggedReason: flaggedReason,
            noOfPostReportedByHim: noOfPostReportedByHim,
            noOfReportedPosts: noOfReportedPosts
        }

        if(flaggedReason == ''){
          alert('Please enter reason')
      }
        else{
            dispatch(flagPost(flaggedPost, navigation));
        }
         }
    
  return (
    <View style={styles.container}>
    {/*<KeyboardAvoidingView behavior="position" enabled  style={styles.container}>*/}
    <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
    <Text></Text>
    <View>      

    <View style={{ 
      justifyContent: 'center',
    alignItems: 'center',
    }}>  
    
    
    <ImageBackground style={{width: '100%', height: 220,
      borderRadius: 20,
      }} 
      imageStyle={{ borderRadius: 20 }}
      source={{uri: url}} >
     
      </ImageBackground>
    
   
    </View>            

    <View style={{padding: 5, flex: 1, flexDirection:'row'}}><Text style={{color: '#000', fontSize: 16}}>{title}</Text><Text style={{color: 'gray', fontSize: 16}}>({category})</Text></View>
    <View style={{padding: 5}}><Text style={{color: 'gray', fontSize: 14}}><FontAwesome name='map-marker' size={20} color='gray' /> {location}</Text></View>
    <View style={{paddingTop: 5, paddingLeft: 5}}><Text style={{color: 'gray', fontSize: 16}}>{description}</Text></View>

        



    <View style={{padding: 10}}>                    
        <TextInput style={{ height:100, borderRadius: 10, borderColor: 'gray', borderWidth: 1, fontFamily: 'Poppins-Regular', padding: 10, textAlignVertical: 'top' }} value={flaggedReason} multiline onChangeText={flaggedReason => setFlaggedReason(flaggedReason)} placeholderTextColor = "black" placeholder='Reason' />
    </View>

    <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 30, paddingBottom: 30, flexDirection: 'row' }}>  
      <View >  
                    <TouchableOpacity onPress={Post}>
                    <View>    
                    <Image source={require('../assets/Button-Bg.png')} style={{width: 165, height: 65/*, textAlign: 'center'*/}} />
                    <Text style={styles.buttonCentered1}>Update</Text>
                    </View>
                    </TouchableOpacity>
                    </View>
                    
<View >  
                    <TouchableOpacity onPress={() => navigation.navigate('Feed')}>
                    <View>    
                      <Image source={require('../assets/cancel.png')} style={{width: 165, height: 65,/* textAlign: 'center'*/}} />
                      <Text style={styles.buttonCentered1}>Cancel</Text>
                    </View>
                    </TouchableOpacity>
                    </View>
                  

                    </View>
                </View>
                <Text></Text>
                </ScrollView>
              {/*</KeyboardAvoidingView>*/}
              </View>
  );
}

export default FlagAsInappropriate;


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'stretch',
        justifyContent: 'center',
        marginLeft: 20,
        marginRight: 20,
        flexDirection: 'column',
        fontFamily: 'Poppins-Regular',
    },
    inputBox: {
        height: 70,
        margin: 0,
        padding: 5,
        fontSize: 14,
        color: 'gray',
        borderBottomColor: 'gray',
        borderBottomWidth: 0.5,
        fontWeight: 'normal',
        fontFamily: 'Poppins-Regular'
    },
    terms: {
      margin: 10,
      padding: 15,
      fontSize: 16,
      fontWeight: 'normal',
        fontFamily: 'Poppins-Regular',
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center'
  },
  headerButtonsContainer: {
    flexDirection:'row',        
    paddingLeft: 5,  
    paddingRight: 5,
    alignItems: 'center',  
    fontFamily: 'Poppins-Regular'
  },
  headerButtons: {
    padding: 10,
    color: '#1C9E0B',
    fontFamily: 'Poppins-Regular'
  },
    button: {
        marginTop: 10,
        marginBottom: 20,
        paddingVertical: 5,
        position: 'relative',
        textAlign: 'center',
        alignItems: 'center',
        width: 150,
        height: 40,
        backgroundColor: '#BEBEC0',
        borderColor: '#BEBEC0',
        borderWidth: 1,
        borderRadius: 5,
        justifyContent: 'center',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText1: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonText2: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonSignup: {
        fontSize: 12,
        fontWeight: 'normal',
          fontFamily: 'Poppins-Regular'
    },
    buttonContainer: {
      position: 'relative',
      textAlign: 'center',
      color: '#fff',
      fontFamily: 'Poppins-Regular',
      width: 150,
      height: 100,
      justifyContent: 'center',
      alignItems: 'center',
    },
    buttonCentered1: {
      position: 'absolute',
      top: '32%',
      left: '37%',
      color: '#000',
      fontWeight: 'bold',
      fontFamily: 'Poppins-Regular',
      fontSize: 18,
    },
});
