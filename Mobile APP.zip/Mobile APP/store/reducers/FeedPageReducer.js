import { FEED_DATA, COMMENT_DATA, LIKES_DATA, LIKEDUSER_LIST, COMMENTS_COUNT , PROFILE_PICTURE} from '../actions/actionTypes';


let InitialState = {           
    datasLength: '0',          
    datas: [],
    isFetching: true,   
    commentsData: [],
    persons: [],
    likesData: '',
    likesDataList: [],
    commentsCountData: '',
    commentsData: null,
    commentLength: '0',
    likedDetails: null,
    profileUrls: '',
}

// A very simple reducer
function FeedPageReducer(state = InitialState, action) {  
  
    switch (action.type) {
      case FEED_DATA:     
      const { datasLength, datas, isFetching } = action.payload;      
        return {
            ...state,              
            datasLength: datasLength,
            datas: datas,
            isFetching: isFetching                              
        };  

        case LIKES_DATA:  
        const { likeCount, likedUser } = action.payload;                  
          return {
            ...state,
            likesData: likeCount,
            likesDataList: likedUser
          };

        case LIKEDUSER_LIST:          
          return {
            ...state,
            likedDetails: action.payload,            
          };

          case COMMENTS_COUNT:            
          return {
            ...state,
            commentsCountData: action.payload            
          };

        case COMMENT_DATA:        
        return {
          ...state,              
          commentsData: action.payload,
          commentLength: '1',          
        };  
        case PROFILE_PICTURE:
          return {
            ...state,
            profileUrls: action.payload,
          }        
      default:
        return state;                    
    }
  }

  export default FeedPageReducer;