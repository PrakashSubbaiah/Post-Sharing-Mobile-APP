import { LOGIN, LOGOUT, SIGNUP, GET_ERRORS } from '../actions/actionTypes';


let InitialState = {           
    errorMessage: '',          
    errorCode: '',
    checkUid: '',
    checkStatus: '',
    userDetails: [] || null,
    status: false,          
    authToken: false,    
}

// A very simple reducer
function loginPathReducer(state = InitialState, action) {  
  
    switch (action.type) {
      case SIGNUP:                
        return {
            ...state,                    
            userDetails: null,
            authToken: false,
            errorCode: null 
        };
      case LOGIN:                                                        
        return {
            ...state,                    
            userDetails: action.payload,            
            authToken: true
        };

      case LOGOUT:
        return {
            ...state,                     
            userDetails: null,
            errorCode: null,
            authToken: false     
        };
        case GET_ERRORS: 
        return {
            ...state,            
            errorCode: action.payload.code
        }
      default:
        return state;                    
    }
  }

  export default loginPathReducer;