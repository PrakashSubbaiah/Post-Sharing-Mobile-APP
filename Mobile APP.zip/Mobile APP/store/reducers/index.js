import { combineReducers } from 'redux';


import loginPathReducer from './loginPathReducer';

const rootReducer = combineReducers({      
    loginPath: loginPathReducer
  });
  
export default rootReducer;