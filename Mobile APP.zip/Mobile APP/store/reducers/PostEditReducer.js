import { EDITPOST_DATA } from '../actions/actionTypes';


let InitialState = {       
    datas: [],    
}

// A very simple reducer
function PostEditReducer(state = InitialState, action) {  
  
    switch (action.type) {
      case EDITPOST_DATA:                 
        return {
            ...state,                          
            datas: action.payload
        };        

      default:
        return state;                    
    }
  }

  export default PostEditReducer;