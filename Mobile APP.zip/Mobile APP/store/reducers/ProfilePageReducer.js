import { MYPOST_DATA, WARNING_DATA } from '../actions/actionTypes';


let InitialState = {   
    datasLength: '0',
    datas: [],  
    warningLengthData: '0',
    warningData: []  
}

// A very simple reducer
function ProfilePageReducer(state = InitialState, action) {  
  
    switch (action.type) {
      case MYPOST_DATA:           
      const { datasLengthData, datasData } = action.payload;      
        return {
            ...state,              
            datasLength: '1',
            datas: datasData
        };
        
      case WARNING_DATA:                 
        const { warningLengthData, warningDatas } = action.payload;      
          return {
              ...state,              
              warningLength: warningLengthData,
              warningData: warningDatas
          };
      default:
        return state;                    
    }
  }

  export default ProfilePageReducer;


  