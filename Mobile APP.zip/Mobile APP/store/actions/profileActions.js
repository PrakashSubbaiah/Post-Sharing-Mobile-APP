import { FEED_DATA, COMMENT_DATA, MYPOST_DATA, WARNING_DATA } from "./actionTypes";
import 'firebase/firestore';
import * as firebase from 'firebase';
import { auth, firestore, storage } from '../../Config/Config';
import moment from 'moment';
import {AsyncStorage} from 'react-native';

      export const mypostData = (userId) => dispatch => {   
        let dataPayload = [];    
        
        var docRef = firestore.collection("users").doc(userId);
        let myPostList = [];
        
        docRef.get().then(function(doc) {  
            
            if (doc.exists) {
                
                //console.log("Document data:", doc.data().myPost);        
                    
                    if(doc.data().myPost){        
                        myPostList = Object.values(doc.data().myPost);            

                        let newArray = myPostList.filter(function (el) {
                            return el.deleteFlag == false;
                          });
                          
                          //console.log(returnArr);
                          newArray = newArray.sort(function(a, b) {              
                            return (new Date(moment.unix(b.postedUnix)) - new Date(moment.unix(a.postedUnix)));
                        });
                    let dataPayload = {
                        datasLengthData: '1',
                        datasData: newArray
                    }                        
                  //  console.log(dataPayload);
                    return dispatch({
                        type: MYPOST_DATA,
                        payload: dataPayload
                    });
                }else {
                    
                    // doc.data() will be undefined in this case
                    console.log("No such document!");
                
                    let dataPayload = {
                        datasLengthData: '1',
                        datasData: myPostList
                    }                        
    
                    return dispatch({
                        type: MYPOST_DATA,
                        payload: dataPayload
                    });
                }
                            
            } else {
                
                // doc.data() will be undefined in this case
                console.log("No such document!");
            
                let dataPayload = {
                    datasLengthData: '1',
                    datasData: myPostList
                }                        

                return dispatch({
                    type: MYPOST_DATA,
                    payload: dataPayload
                });
            }
        }).catch(function(error) {
            
            console.log("Error getting document:", error);
            
            let dataPayload = {
                datasLengthData: '1',
                datasData: myPostList
            }                        

            return dispatch({
                type: MYPOST_DATA,
                payload: dataPayload
            });
        });


           
          };     


       export const profilePicture = async (uri, imageName, userId) => {
       
        let profileUrls = '';
        let imageNames = '';
       
          const response = await fetch(uri);
          const blob = await response.blob();
      
          await storage.ref().child("profile/" + imageName).put(blob);
          
          await storage.ref('profile').child(imageName).getDownloadURL().then(url => {                
                profileUrls = url;
                imageNames = imageName;
                firestore.collection('users').doc(userId).update({ profileUrl: profileUrls, imageName: imageNames}).then(() => {
                   /* let updatedProfileData = {                    
                        profileUrl: profileUrls
                    }                              */
                    alert("success");                  
                    return profileUrls;
                  });
            });
      
        
        }; 

        



        export const warningData = (userId) => dispatch => {   
            let dataPayload = [];
            firestore.collection('users').doc(userId).get().then((doc) => {
                                    
                let returnArr = [];
            
                dataPayload = {
                    warningLengthData: '1',
                    warningDatas: doc.data()
                }                                 
               
                return dispatch({
                    type: WARNING_DATA,
                    payload: dataPayload
                });
                
            });     
                             
               
              };

        
