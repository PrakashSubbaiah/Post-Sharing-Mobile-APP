import { EDITPOST_DATA, MYPOST_DATA } from "./actionTypes";
import 'firebase/firestore';
import * as firebase from 'firebase';
import { firestore } from '../../Config/Config';
import moment from 'moment';
import { Alert } from 'react-native';

export const editPostData = (doc_idtest) => dispatch => {   
    let dataPayload = [];

    firestore.collection('post').doc(doc_idtest).get().then((doc) => {          
        if(doc.exists){
            dataPayload = {
                category: doc.data().category,
                title: doc.data().title,
                location: doc.data().location,
                description: doc.data().description,
                url: doc.data().url,
                doc_id: doc.data().doc_id,
                share: doc.data().share,
                userId: doc.data().userUid,                
            }
            return dispatch({
                type: EDITPOST_DATA,
                payload: dataPayload
            });
        }        
    });                      
       
};



export const editPostUpdate = (doc_id, description, share, userId, dispatch, navigation) => {       

    firestore.collection('post').doc(doc_id).update({ description: description, share: share })
          .then(() => { 

            firestore.collection('users').doc(userId).set({
                myPost: {
                  [doc_id]: {description: description, share: share},
                },
              }, { merge: true }).then(() => {
               // alert("Post updated successfully");                
                //return true;










        var docRef = firestore.collection("users").doc(userId);
        let myPostList = [];
        
        docRef.get().then(function(doc) {  
            
            if (doc.exists) {                                  
                    
                    if(doc.data().myPost){        
                        myPostList = Object.values(doc.data().myPost);            

                        let newArray = myPostList.filter(function (el) {
                            return el.deleteFlag == false;
                          });
                          
                          //console.log(returnArr);
                          newArray = newArray.sort(function(a, b) {              
                            return (new Date(moment.unix(b.postedUnix)) - new Date(moment.unix(a.postedUnix)));
                        });
                    let dataPayload = {
                        datasLengthData: '1',
                        datasData: newArray
                    }                        
                    //alert("Post updated successfully");
                    Alert.alert(
                        'Post',
                        'Updated successfully.',
                        [
                          {text: 'OK', onPress: () => navigation.navigate('Profile')},
                        ],
                        { cancelable: false }
                      );
                    return dispatch({
                        type: MYPOST_DATA,
                        payload: dataPayload
                    });
                }
                            
            } 
        }).catch(function(error) {
            
            console.log("Error getting document:", error);
            
            let dataPayload = {
                datasLengthData: '1',
                datasData: myPostList
            }                        

            return dispatch({
                type: MYPOST_DATA,
                payload: dataPayload
            });
        });



















              });              
            }
          );                   
       
};