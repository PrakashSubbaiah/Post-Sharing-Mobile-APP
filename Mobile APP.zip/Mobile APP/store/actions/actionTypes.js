export const INCREMENT = "INCREMENT";

export const DECREMENT = "DECREMENT";

export const LOGIN = "LOGIN";

export const LOGOUT = "LOGOUT";

export const SIGNUP = "SIGNUP";

export const GET_ERRORS = "GET_ERRORS";

export const PROFILE_PICTURE = "PROFILE_PICTURE";

export const FEED_DATA = "FEED_DATA";

export const LIKES_DATA = "LIKES_DATA";

export const LIKEDUSER_LIST = "LIKEDUSER_LIST";

export const COMMENTS_COUNT = "COMMENTS_COUNT";

export const COMMENT_DATA = "COMMENT_DATA";

export const MYPOST_DATA = "MYPOST_DATA";

export const EDITPOST_DATA = "EDITPOST_DATA";

export const WARNING_DATA = "WARNING_DATA";



