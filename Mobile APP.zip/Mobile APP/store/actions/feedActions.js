import { FEED_DATA, COMMENT_DATA, GET_ERRORS, LIKES_DATA, COMMENTS_COUNT, LIKEDUSER_LIST, MYPOST_DATA, PROFILE_PICTURE } from "./actionTypes";
import 'firebase/firestore';
import * as firebase from 'firebase';
import { auth, firestore } from '../../Config/Config';
import moment from 'moment';
import {AsyncStorage} from 'react-native';

import { Alert } from 'react-native';

// User Profile Picture Get
export const getProfilePicture = () => dispatch => {           
 
  firestore.collection('userProfilePicture').get().then((querySnapshot) => {                       
  
    let returnArrays = [];          
    querySnapshot.forEach(function(doc){          
        returnArrays.push(doc.data());                           
    });   
       
    var result = returnArrays.reduce(function(result, item){     
      return item;
    }, {});   
   // console.log(result);
    return dispatch({
      type: PROFILE_PICTURE,      
      payload: result
    });  
      
  });

};


// Feed Data Get
export const feedData = (userId) => dispatch => {           
  
    firestore.collection('post').where("deleteFlag", "==", false).where("postFlagged", "==", false).get().then((querySnapshot) => {                
        
        let returnArr = [];          
        querySnapshot.forEach(function(doc){    
          if((doc.data().userUid) != userId){
              returnArr.push(doc.data());   
            }                        
        })
        //console.log(returnArr);
        returnArr = returnArr.sort(function(a, b) {              
                        return (new Date(moment.unix(b.postedUnix)) - new Date(moment.unix(a.postedUnix)));
                    });
                           
        let dataPayload = {
            datasLength: '1',
            datas: returnArr,
            isFetching: false
        }
      //console.log(dataPayload);
        return dispatch({
            type: FEED_DATA,
            payload: dataPayload
        });

      });

};


 
// Likes Data Get
export const likeData = () => dispatch => {           
 
  firestore.collection('countLikes').get().then((querySnapshot) => {                       

    let returnArrays = [];          
    querySnapshot.forEach(function(doc){          
        returnArrays.push(doc.data());                           
    });   
       
    var result = returnArrays.reduce(function(result, item){     
      return item;
    }, {});   
    
    AsyncStorage.getItem('userDetail').then((user_data_json) => {
      let userData = JSON.parse(user_data_json);                                  
        firestore.collection('userLikes').doc(userData.user.uid).get().then((doc) => {                       

          let returnArraysss = [];              
          returnArraysss = doc.data();     
          let likePayload = {
            likeCount: result,
            likedUser: returnArraysss
          }          
          return dispatch({
            type: LIKES_DATA,      
            payload: likePayload
          });  
        });     
    });        
  });

};



//Liked Details Get
export const likedDetail = (doc_id) => dispatch => {           

var docRef = firestore.collection("likedUsersList").doc(doc_id);

docRef.get().then(function(doc) {  
    if (doc.exists) {
       // console.log("Document data:", doc.data());        
        let likedUser = null;    
            if(doc.data().likedUsers){        
              likedUser = Object.values(doc.data().likedUsers);  
              likedUser = likedUser.filter(function (el) {
                return el.flag == "active";
              });          
            }else{
              likedUser = null;                        
            }
        return dispatch({
          type: LIKEDUSER_LIST,
          payload: likedUser
        });
    } else {
 
        console.log("No such document!");
        return dispatch({
          type: LIKEDUSER_LIST,
          payload: null            
        });
    }
}).catch(function(error) {
    console.log("Error getting document:", error);
    return dispatch({
      type: LIKEDUSER_LIST,
      payload: null            
    });
});

};

/*Likes Update*/
export const likeUpdate = (person, userId, username, email, phone, likeNumber, dispatch) => {   
      
   let likes = person.likes;    
   let likedUsers = likedUsers+Number(likes)+1;

        firestore.collection('likedUsersList').doc(person.doc_id).set({ ['likedUsers']: { [phone]: { 
          phone: phone,
          email: email,
          username: username,           
          userId: userId,
          likedDate: moment().unix(),
          flag: 'active' }
        }}, {merge: true}).then(()=>{
          firestore.collection('countLikes').doc('noOfLikes').set({ [person.doc_id]: likeNumber+1 }, { merge: true }).then(()=>{             
            firestore.collection('userLikes').doc(userId).set({ [person.doc_id]: "active" }, { merge: true }).then(()=>{ 
              console.log('likes updated');    

              /*Updated details refresh in Reducer Start*/
                firestore.collection('countLikes').get().then((querySnapshot) => {                       
                    let returnArrays = [];          
                    querySnapshot.forEach(function(doc){          
                        returnArrays.push(doc.data());                           
                    });   
                    var result = returnArrays.reduce(function(result, item){     
                      return item;
                    }, {});                   
                    AsyncStorage.getItem('userDetail').then((user_data_json) => {
                      let userData = JSON.parse(user_data_json);                                  
                        firestore.collection('userLikes').doc(userData.user.uid).get().then((doc) => {                       
                          let returnArraysss = [];              
                          returnArraysss = doc.data();     
                          let likePayload = {
                            likeCount: result,
                            likedUser: returnArraysss
                          }                    
                          return dispatch({
                            type: LIKES_DATA,      
                            payload: likePayload
                          });    
                        });     
                    });
                  });
              /*Updated details refresh in Reducer End*/
             
            });
          });
        });            
  };

  /*Dislike update*/
  export const dislikeUpdate = (person, userIds, username, email, phones, likesCount, dispatch) => {   
       
    let likes = person.likes;      
    let userId = userIds;                      

      firestore.collection('likedUsersList').doc(person.doc_id).set({ ['likedUsers']: { [phones]: { 
        phone: phones,
        email: email,
        username: username,         
        userId: userId,
        likedDate: moment().unix(),
        flag: 'inactive' }
      }}, {merge: true}).then(()=>{
        firestore.collection('countLikes').doc('noOfLikes').set({ [person.doc_id]: likesCount-1 }, { merge: true }).then(()=>{             
          firestore.collection('userLikes').doc(userIds).set({ [person.doc_id]: "inactive" }, { merge: true }).then(()=>{ 
            console.log('dislikes updated')
          
            
            /*Updated details refresh in Reducer Start*/
            firestore.collection('countLikes').get().then((querySnapshot) => {                       
                let returnArrays = [];          
                querySnapshot.forEach(function(doc){          
                    returnArrays.push(doc.data());                           
                });             
                var result = returnArrays.reduce(function(result, item){     
                  return item;
                }, {});    
                AsyncStorage.getItem('userDetail').then((user_data_json) => {
                  let userData = JSON.parse(user_data_json);                                  
                    firestore.collection('userLikes').doc(userData.user.uid).get().then((doc) => {                       
                      let returnArraysss = [];              
                      returnArraysss = doc.data();    
                      let likePayload = {
                        likeCount: result,
                        likedUser: returnArraysss
                      }         
                      return dispatch({
                        type: LIKES_DATA,      
                        payload: likePayload
                      });    
                    });     
                });         
            });
            /*Updated details refresh in Reducer End*/

       
          });
        });
      });                  
  };



//Comment Count Get
export const commentsData = () => dispatch => {           
  firestore.collection('countComments').get().then((querySnapshot) => {                       
    let returnArrays = [];          
    querySnapshot.forEach(function(doc){          
        returnArrays.push(doc.data());                           
    });   
    var result = returnArrays.reduce(function(result, item){     
      return item;
    }, {});   
    return dispatch({
            type: COMMENTS_COUNT,      
            payload: result
          });            
  });
};


//Get Comment Data
export const commentData = (docRefId) => dispatch => {                        
    firestore.collection('commentsPost').doc(docRefId).get().then((doc) => {          
        if(doc.exists){
          let personData = doc.data();
          let commentsData = [];
          if(personData.Comments){        
            commentsData = Object.values(personData.Comments);            
          }else{
            commentsData = null;                        
          }                    
          return dispatch({
            type: COMMENT_DATA,
            payload: commentsData
          });                 

        }else{
           let commentsData = null;                        
        return dispatch({
            type: COMMENT_DATA,
            payload: commentsData
          });
        }
      }).catch(() => {
        let commentsData = null;                        
        return dispatch({
            type: COMMENT_DATA,
            payload: commentsData
          });
      });   
};


/*Updated Comment data and count*/
export const handleComment = (comments, userId, username, email, phone, person, countComment, dispatch) =>  {   
    
    let doc_id = person.doc_id;                    

          firestore.collection('commentsPost').doc(doc_id).set({Comments: firebase.firestore.FieldValue.arrayUnion({
            phone: phone, 
            email: email, 
            username: username,
            userId: userId,
            commentDate: moment().unix(),
            comment: comments,
            flag: 'active'})
          }, { merge: true }).then(()=>{            
            firestore.collection('countComments').doc('noOfComments').set({[doc_id]: countComment+1}, { merge: true }).then(()=>{                               
              console.log("Comment Posted");
                
             


              /*Updated details refresh in Reducer Start*/                            
              firestore.collection('commentsPost').doc(doc_id).get().then((doc) => {    
                console.log("Comment Posted 1");      
                  if(doc.exists){
                   // console.log("Comment Posted 2");
                    let personData = doc.data();
                    let commentsData = [];
                    if(personData.Comments){     
                      //console.log("Comment Posted 3");   
                      commentsData = Object.values(personData.Comments);            
                    }else{
                      commentsData = null;                        
                    }          
                    /*return dispatch({
                      type: COMMENT_DATA,
                      payload: commentsData
                    });*/

                    /*Update Comments and comments count in reducer start*/
                    firestore.collection('countComments').get().then((querySnapshot) => {    
                      //console.log("success 1");
                      let returnArrays = [];          
                      querySnapshot.forEach(function(doc){          
                          returnArrays.push(doc.data());                           
                      });   
                      //console.log("success 2");
                      var result = returnArrays.reduce(function(result, item){     
                        return item;
                      }, {});   
                     // console.log("success 3");
                      
                      return dispatch({
                        type: COMMENTS_COUNT,      
                        payload: result
                      });
                            

                    });
                    /*Update Comments and comments count in reducer end*/
                    

                  }else{
                    let commentsData = null;                        
                  return dispatch({
                      type: COMMENT_DATA,
                      payload: commentsData
                    });
                  }
                }).catch(() => {
                  let commentsData = null;                        
                  return dispatch({
                      type: COMMENT_DATA,
                      payload: commentsData
                    });
                }); 
                /*Updated details refresh in Reducer End*/

            });            
        });         
};

/*Update Flag Data*/
export const flagPost = (flaggedPost, navigation) => dispatch => {

  let reportedPostByHim = flaggedPost.noOfPostReportedByHim;
  let reportedPostsByHim = Number(reportedPostByHim)+1;

  let reportedPost = flaggedPost.noOfReportedPosts;
  let reportedPosts = Number(reportedPost)+1;
  
  firestore.collection('post').doc(flaggedPost.flagged_post_id).set({ 
    ['flaggedBy']: { [flaggedPost.flaggedPhone]: {
    flaggedPhone: flaggedPost.flaggedPhone,
    flaggedBy: flaggedPost.flaggedBy,
    flaggedEmail: flaggedPost.flaggedEmail,
    flaggedUid: flaggedPost.flaggedUid,
    flaggedUnix: moment().unix(),
    adminFlag: flaggedPost.adminFlag,
    flaggedReason: flaggedPost.flaggedReason,
   }
 },
 postFlagged: true,
 }, {merge: true}).then(() => {
    firestore.collection('users').doc(flaggedPost.flaggedUid).update({
      noOfPostReportedByHim : reportedPostsByHim
    })
  }).then(() => {
    firestore.collection('users').doc(flaggedPost.userUid).update({
      noOfReportedPosts : reportedPosts
    })
  }).then(()=>{                        
    Alert.alert(
      'Post',
      'Successfuly post is flagged inappropriate.',
      [
        {text: 'OK', onPress: () => navigation.navigate('FeedTab')},
      ],
      { cancelable: false }
    );

    }).catch(error => 
        {
        console.log("Error");
        dispatch({
            type: GET_ERRORS,
            payload: error
          })
        }
        )
    
  };
        

  export const postPost = (newPost, myPost, navigation) => dispatch => {
  
    let numberOfPost = newPost.numberOfPosts;
    let numberOfPosting = Number(numberOfPost)+1;
    let postedDocId;
    firestore.collection('post').add(newPost).then((docRef) => {     
      firestore.collection('post').doc(docRef.id).update({doc_id: docRef.id});
      
      postedDocId = docRef.id;
  
      console.log("Post added");
  
    }).then(() => {
      firestore.collection('users').doc(newPost.userUid).update({
        numberOfPosts : numberOfPosting,            
      }).then(()=>{     
  
        console.log("number of posting updated in users");
  
        //MyPost add in users list           
        firestore.collection('users').doc(newPost.userUid).set({
          myPost: {
            [postedDocId]: myPost,
          },
        }, { merge: true }).then(()=>{  
          firestore.collection('users').doc(newPost.userUid).set({
              myPost: {
                [postedDocId]: {doc_id: postedDocId},
              },
            }, { merge: true });
  
          console.log("Post details updated in users");
        //MyPost comments count add in users list
        firestore.collection('users').doc(newPost.userUid).set({
          myPostCommentsCount: {
            [postedDocId]: 0,
          },
        }, { merge: true }).then(()=>{  
          console.log("update comments count in users");
          //Mypost likes count add in users list                                            
          firestore.collection('users').doc(newPost.userUid).set({              
            myPostLikesCount: {
              [postedDocId]: 0,
             },

          }, { merge: true }).then(()=>{  
            console.log("update likes count in users");
            firestore.collection('countComments').doc('noOfComments').set({ [postedDocId]: 0 }, { merge: true }).then(()=>{ 
              console.log("update count comment in seprately");
            firestore.collection('countLikes').doc('noOfLikes').set({ [postedDocId]: 0 }, { merge: true }).then(()=>{ 
              console.log("update count like in seprately");                                            
                  console.log("successfully posted");
                  //alert("successfuly posted");
                 // return true;          
                  
                  
                 







                 let dataPayload = [];    
        
        var docRef = firestore.collection("users").doc(newPost.userUid);
        let myPostList = [];
        
        docRef.get().then(function(doc) {  
            
            if (doc.exists) {
                
                console.log("Document data:", doc.data().myPost);        
                    
                    if(doc.data().myPost){        
                        myPostList = Object.values(doc.data().myPost);            

                        let newArray = myPostList.filter(function (el) {
                            return el.deleteFlag == false;
                          });
                        newArray = newArray.sort(function(a, b) {              
                            return (new Date(moment.unix(b.postedUnix)) - new Date(moment.unix(a.postedUnix)));
                        });
                    let dataPayload = {
                        datasLengthData: '1',
                        datasData: newArray
                    }                        
                    console.log(dataPayload);
                    console.log("Passing");
                    let data = "success";
                    alert(data);
                    return data;
                    
                    //Alert.alert("Successfuly posted.");

                    /*Alert.alert(
                      'Post',
                      'Successfuly posted.',
                      [
                        {text: 'OK', onPress: () => navigation.navigate('ProfileTab')},
                      ],
                      { cancelable: false }
                    );
                                     

                    return dispatch({
                        type: MYPOST_DATA,
                        payload: dataPayload
                    });*/


                }else {
                    
                    // doc.data() will be undefined in this case
                    console.log("No such document!");
                
                    let dataPayload = {
                        datasLengthData: '1',
                        datasData: myPostList
                    }                        
    
                    return dispatch({
                        type: MYPOST_DATA,
                        payload: dataPayload
                    });
                }
                            
            } else {
                
                // doc.data() will be undefined in this case
                console.log("No such document!");
            
                let dataPayload = {
                    datasLengthData: '1',
                    datasData: myPostList
                }                        

                return dispatch({
                    type: MYPOST_DATA,
                    payload: dataPayload
                });
            }
        }).catch(function(error) {
            
            console.log("Error getting document:", error);
            
            let dataPayload = {
                datasLengthData: '1',
                datasData: myPostList
            }                        

            return dispatch({
                type: MYPOST_DATA,
                payload: dataPayload
            });
        });




            });
            });
          }); 
        });    
        
      })            
      })
    }).catch(error => 
          {
          console.log("Error");
          dispatch({
              type: GET_ERRORS,
              payload: error
            })
          }
          )
      
    };
  



