import { LOGIN, LOGOUT, SIGNUP, GET_ERRORS } from "./actionTypes";
import 'firebase/firestore';
import { auth, firestore } from '../../Config/Config';
import moment from 'moment';
import {AsyncStorage} from 'react-native';
import { Alert } from 'react-native';

// Signup
export const signupUser = (newUser, navigation) => dispatch => {    

  auth.createUserWithEmailAndPassword(newUser.email, newUser.password)
  .then((userData) => {            
    firestore.collection('users').doc(userData.user.uid).set(newUser);     

    Alert.alert(
      'Signed Up',
      'Successfully Create New Account.',
      [
        {text: 'OK', onPress: () => navigation.navigate('Login')},
      ],
      { cancelable: false }
    );
    
  })
    .catch(error => 
      {
      console.log(error);
      dispatch({
          type: GET_ERRORS,
          payload: error
        })
      }
      )
  
};


// Login - Set userDate
export const loginUser = authData => dispatch => {    

    auth.signInWithEmailAndPassword(authData.email, authData.password)
    .then((userData) => {            
            
      const setValue = async () => {  
        let mem =  true;
        await AsyncStorage.setItem('userData', JSON.stringify(mem));
      }
      setValue();  
      
      const setValueUserDetail = async () => {  
        let mem =  true;
        await AsyncStorage.setItem('userDetail', JSON.stringify(userData));
      }
      setValueUserDetail();   

     // console.log(userData);
     firestore.collection('users').doc(userData.user.uid).get().then((doc) => {
    
        if(doc.data().status == 'active'){
                    
          firestore.collection('users').doc(userData.user.uid).update({ lastLoggedIn: moment().unix(), lastLoggedInDate: moment().format('L'), lastLoggedInTime: moment().format('LTS')}).then(() => {                                 
          return dispatch({
                type: LOGIN,
                payload: userData
            });
          })
         
        }
        else {
          AsyncStorage.removeItem('userData').then(() => {
            auth.signOut()
            .then(() => {
              alert("Error 1");
                console.log("Error 1");
            }                        
            )
              .catch(error => 
                {
                alert("Error 2");
                console.log("Error 2");
                dispatch({
                    type: LOGOUT,
                    payload: error
                  })
                })    
          });
        }
      })
    })
      .catch(error => 
        {
       //   alert("Error 3");
        console.log(error);
        dispatch({
            type: GET_ERRORS,
            payload: error
          })
        }
        )
    
  };
  
  // Log user out
export const logoutUser = () => dispatch => {     
  
  const setValueEmpty = async () => {  
    let mems =  false;
    let userDetail = "";
    await AsyncStorage.setItem('userData', JSON.stringify(mems));
    await AsyncStorage.setItem('userDetail', JSON.stringify(userDetail));
    return dispatch({
      type: LOGOUT,
      payload: null
    })
  }
  setValueEmpty();  
  
  
};