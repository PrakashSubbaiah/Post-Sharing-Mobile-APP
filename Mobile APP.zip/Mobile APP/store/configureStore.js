import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import userReducer from './reducers/';
import loginPathReducer from "./reducers/loginPathReducer";
import FeedPageReducer from "./reducers/FeedPageReducer";
import ProfilePageReducer from "./reducers/ProfilePageReducer";
import PostEditReducer from "./reducers/PostEditReducer";



const rootReducer = combineReducers({    
    loginPath: loginPathReducer,
    FeedPage: FeedPageReducer,
    ProfilePage: ProfilePageReducer,
    PostEdit: PostEditReducer
});

const configureStore = () => {
    return createStore(rootReducer, applyMiddleware(thunk));
};

export default configureStore;