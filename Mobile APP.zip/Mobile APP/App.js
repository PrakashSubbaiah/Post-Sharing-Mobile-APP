import React, { useState, useEffect } from 'react';
import { Provider } from 'react-redux';
import { YellowBox } from 'react-native';
import * as Font from 'expo-font';
import { AppLoading } from 'expo';
import AppHome from './Screens/AppHome';

import configureStore from "./store/configureStore";
const store = configureStore();

function Apps() {    
  return (
    <Provider store={store}>
          <AppHome />            
    </Provider>
  );
}

export default function App() {
  
  const [isReady, setReady] = useState(false);
  useEffect(() => {
    YellowBox.ignoreWarnings(['Remote debugger']);    
    console.disableYellowBox = true;
    console.ignoredYellowBox = ['Remote debugger'];
    console.ignoredYellowBox = ['Setting a timer'];
  });

  const fetchFonts = async () => {
    return Font.loadAsync({
      'Poppins-Regular': require('./assets/Fonts/Poppins-Regular.ttf'),
      'Poppins-Medium': require('./assets/Fonts/Poppins-Medium.ttf'),
      'Poppins-Italic': require('./assets/Fonts/Poppins-Italic.ttf'),      
      'Poppins-Bold': require('./assets/Fonts/Poppins-Bold.ttf'),       
      'Poppins-SemiBold': require('./assets/Fonts/Poppins-SemiBold.ttf')
    });
  }  

  return (
    isReady === false ? 
    <AppLoading
      startAsync={fetchFonts}
      onFinish={() => setReady(true)}
      onError={console.warn}
    />
    :
    <Apps/>  
  );
      
}
