import firebase from 'firebase';
//import * as firebase from 'firebase';
import 'firebase/firestore';

var config = {
  apiKey: "AIzaSyDEvZgnn1zE5iIEHIjKks-_854V-n-yzH4",
  authDomain: "iotr-mobileapp.firebaseapp.com",
  databaseURL: "https://iotr-mobileapp.firebaseio.com",
  projectId: "iotr-mobileapp",
  storageBucket: "iotr-mobileapp.appspot.com",
  messagingSenderId: "540135822119",
  appId: "1:540135822119:web:601621da71ead408734f02",
  measurementId: "G-750RE70ZNT"
};

/*if (!firebase.apps.length) {
    firebase.initializeApp(config);
  }*/
firebase.initializeApp(config);

const auth = firebase.auth();
const storage = firebase.storage();
const firestore = firebase.firestore();

export { auth, firestore, storage };


