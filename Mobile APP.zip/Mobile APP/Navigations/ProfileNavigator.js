import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import {Image, TouchableOpacity} from 'react-native';

import ProfileScreen from '../Screens/Profile';
import ViewCommentsPostScreen from '../Screens/ViewCommentsPost';
import ViewLikesPostScreen from '../Screens/ViewLikesPost';
import EditPostScreen from '../Screens/EditPost';
import WarningPageScreen from '../Screens/WarningPage';
import ChangePasswordScreen from '../Screens/ChangePassword';

let RootStack = createStackNavigator();

function ProfileNavigator({navigation}) {
    
    return (              
            <RootStack.Navigator initialRouteName="Profile"
            screenOptions={{
                headerBackTitleVisible: false,
                headerBackButton: <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
            }}>
                <RootStack.Screen name="Profile" component={ProfileScreen}
                options={{
                    headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                    headerStyle: {
                    backgroundColor: '#b5b5b5'          
                    },
                    headerTitleStyle: { 
                        width: 250, height: 50
                    },
                    headerTintColor: '#b5b5b5'        
                }}
                />                
                <RootStack.Screen name="ViewCommentsPost" component={ViewCommentsPostScreen} 
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                                                   
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Profile')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),
                    }}
                />                
                <RootStack.Screen name="ViewLikesPost" component={ViewLikesPostScreen} 
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',                        
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                        
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Profile')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),                                                
                    }}
                />                
                <RootStack.Screen name="EditPost" component={EditPostScreen}
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',                        
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                        
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Profile')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),                                                
                    }}
                 />
                <RootStack.Screen name="WarningPage" component={WarningPageScreen} 
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',                        
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                        
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Profile')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),                                                
                    }}
                />
                <RootStack.Screen name="ChangePassword" component={ChangePasswordScreen} 
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',                        
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                        
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Profile')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),                                                
                    }}
                />

            </RootStack.Navigator>                                
    );
  }
  export default ProfileNavigator;

