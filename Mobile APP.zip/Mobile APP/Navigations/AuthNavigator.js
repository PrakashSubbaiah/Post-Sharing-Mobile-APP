import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import LoginScreen from '../Screens/Login';
import SignupScreen from '../Screens/SignupScreen';

const Loginstack = createStackNavigator();

function AuthNavigator() {
  return (     
    <Loginstack.Navigator>
        <Loginstack.Screen options={{ headerShown: false }} name="Login" component={LoginScreen} />
        <Loginstack.Screen options={{ headerShown: false }} name="Signup" component={SignupScreen} />
    </Loginstack.Navigator>    
  );
}

export default AuthNavigator;