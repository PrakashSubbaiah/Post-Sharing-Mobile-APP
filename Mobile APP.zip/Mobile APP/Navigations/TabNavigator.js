import * as React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleSheet, Image } from 'react-native'

import FeedNavigator from './FeedNavigator';
import PostNavigator from './PostNavigator';
import ProfileNavigator from './ProfileNavigator';


const Tab = createBottomTabNavigator();

function TabNavigator({route}) {
  
  return (     
    <Tab.Navigator tabBarOptions={{ style:{ backgroundColor: '#b5b5b5', paddingTop: 10 } }} initialRouteName="FeedTab" >

      <Tab.Screen name="FeedTab" component={FeedNavigator} 
      options={{
        tabBarLabel: '',
        tabBarIcon: ({ focused }) => {                                                
            if(focused){              
              return <Image source={require('../assets/Home-selected.png')} style={styles.tabImage} />            
            }else{
              return <Image source={require('../assets/Home.png')} style={styles.tabImage} />
            }                                
        }      
      }}
      />   
      <Tab.Screen name="PostTab" component={PostNavigator}
      options={{
        tabBarLabel: '',
        tabBarIcon: ({ focused }) => {                   
          if(focused){
            return <Image source={require('../assets/add_post-selected.png')} style={styles.tabImage} />            
          }else{
            return <Image source={require('../assets/add_post.png')} style={styles.tabImage} />
          }
        }      
      }}
      />
      <Tab.Screen name="ProfileTab" component={ProfileNavigator}
       options={{
        tabBarLabel: '',
        tabBarIcon: ({ focused }) => {                   
          if(focused){
            return <Image source={require('../assets/Profile-selected.png')} style={styles.tabImage} />            
          }else{
            return <Image source={require('../assets/Profile.png')} style={styles.tabImage} />
          }
        }      
      }}
      />         
    </Tab.Navigator>    
  );
}

export default TabNavigator;



const styles = StyleSheet.create({ 
  tabImage: {
    width: 25,
    height: 25,
  }
})
