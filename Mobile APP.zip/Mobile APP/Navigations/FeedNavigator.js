import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import {Image, TouchableOpacity} from 'react-native';

import FeedScreen from '../Screens/Feed';
import ViewCommentsScreen from '../Screens/ViewComments';
import FlagAsInappropriateScreen from '../Screens/FlagAsInappropriate';

let RootStack = createStackNavigator();

function FeedNavigator({navigation}) {
    return (              
            <RootStack.Navigator initialRouteName='Feed'>
                <RootStack.Screen name="Feed" component={FeedScreen}                 
                    options={{
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,                        
                        headerStyle: {
                        backgroundColor: '#b5b5b5'          
                        },
                        headerTitleStyle: { 
                            width: 250, height: 50, color: '#fff'
                        },
                        headerTintColor: '#fff'        
                    }}
                 />
                <RootStack.Screen name="ViewComments" component={ViewCommentsScreen}                                                     
                    options={{
                        headerBackTitle: '',
                        headerBackButton: '',                        
                        headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                        headerStyle: { backgroundColor: '#b5b5b5' },
                        headerTitleStyle: { width: 250, height: 50 },                        
                        headerLeft: () => (
                            <TouchableOpacity onPress={()=>{navigation.navigate('Feed')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                            </TouchableOpacity>
                        ),                                               
                    }}
                 />
                 <RootStack.Screen name="FlagAsInappropriate" component={FlagAsInappropriateScreen}
                        options={{
                            headerBackTitle: '',
                            headerBackButton: '',                        
                            headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                            headerStyle: { backgroundColor: '#b5b5b5' },
                            headerTitleStyle: { width: 250, height: 50 },                        
                            headerLeft: () => (
                                <TouchableOpacity onPress={()=>{navigation.navigate('Feed')}} style={{ paddingLeft: 20, paddingRight: 20 }}>                        
                                    <Image source={require('../assets/Backbutton-White1.png')} style={{width: 20, height: 20}} />
                                </TouchableOpacity>
                            ),
                        }}
                 />
            </RootStack.Navigator>                                
    );
  }
  export default FeedNavigator;