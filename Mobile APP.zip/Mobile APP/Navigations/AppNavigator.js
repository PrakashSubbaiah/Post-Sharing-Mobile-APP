import React, { useState, useEffect } from 'react';
import {AsyncStorage} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { useSelector } from 'react-redux';

import TabNavigatorScreen from './TabNavigator';
import AuthNavigatorScreen from './AuthNavigator';

function AppNavigator() {
  
  const [logState, setLogState] = useState(false);
  const selector = useSelector(state => state);  

  useEffect(() => {    
    console.log('App Navigator 1');   
    const checkUserSignedIn = async () => {  
      try {
         let value = await AsyncStorage.getItem('userData');
         console.log("HERE in useEffect ", value);
         if (value == 'true'){                      
          setLogState(true);
         }
         else {          
          setLogState(false);
        }
      } catch (error) {
        // Error retrieving data
      }
  }
  checkUserSignedIn();
  }, [selector.loginPath.userDetails]);

  return (     
        <NavigationContainer>                
          {logState ?
            <TabNavigatorScreen />  
          :               
            <AuthNavigatorScreen />
          }
        </NavigationContainer>
    );
  }

export default AppNavigator;
