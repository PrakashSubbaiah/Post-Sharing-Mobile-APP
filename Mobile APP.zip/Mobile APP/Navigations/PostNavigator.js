import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import {Image} from 'react-native';

import PostScreen from '../Screens/PostScreen';

// Create our stack navigator
let RootStack = createStackNavigator();

function PostNavigator() {
    return (              
            <RootStack.Navigator initialRouteName='Counter'>
                <RootStack.Screen name="Post" component={PostScreen} 
                options={{
                    headerTitle: <Image source={require('../assets/IOTR-Logo-1.png')} style={{width: 105, height: 36,}}/>,
                    headerStyle: {
                    backgroundColor: '#b5b5b5'          
                    },
                    headerTitleStyle: { 
                        width: 250, height: 50
                    },
                    headerTintColor: '#b5b5b5'        
                }}
                />               
            </RootStack.Navigator>                                
    );
  }
  export default PostNavigator;